# E06｜ABBY: Automating leakage modelling for side-channel analysis

- **来源**：PROCEEDINGS OF THE 19TH ACM ASIA CONFERENCE ON COMPUTER AND COMMUNICATIONS SECURITY, ACM ASIACCS 2024。
- **年份说明**：ASIACCS 2024。
- **作者**：Bazangani, Omid Iooss, Alexandre Buhan, Ileana Batina, Lejla。
- **正式入口**：[10.1145/3634737.3637665](https://doi.org/10.1145/3634737.3637665)。
- **收录状态**：按领域重要来源路线保留；正式发表已核，未声称中科院分区或本轮已核CCF级别。
- **阅读优先级 / 难度**：P3 / 中高。
- **内容判断依据**：摘要初筛；未逐节精读或复现实验。
- **全文状态**：全文待补。

## 为什么放在这里

ABBY：自动建立微架构泄漏数据，用于理解数据是怎样产生的。

## 阅读时要回答的问题

指令上下文怎样影响泄漏？模拟泄漏与实测密钥恢复之间如何验证？

## 前置知识

CPA/ASCAD与统计指标；信息论条目需熵、互信息和统计估计基础。

## 原文摘要（供检索与初筛）

Mitigating side-channel leakage in cryptographic components is a vital concern for developers working with embedded devices. Conventional side-channel analysis demands substantial manual effort for setup preparation and trace recording, rendering it more intricate during the dynamic design phase, where software alterations occur frequently. Additionally, identifying the specific instruction(s) responsible for leakage has been hindered by limited hardware descriptions and restricted access to process technology information. We introduce ABBY, an open-source side-channel leakage profiling framework that targets the microarchitectural layer. Existing solutions to characterize the microarchitectural layer are devicespecific and/or require extensive manual effort. ABBY's main innovation is data collection, which can automatically characterize the microarchitectural behaviour of a target device and has the additional benefit of being extendable to other similar devices. Using ABBY, we created two datasets that capture the interaction of instructions for the ARM CORTEX-M0/M3 architecture. These sets are the first to capture detailed information on the microarchitectural layer. They can be used to explore various leakage models suitable for creating side-channel leakage simulators. A preliminary evaluation of a leakage model produced with our dataset of real-world cryptographic implementations shows performance comparable to state-of-the-art leakage simulators.

## 题录证据（核验日：2026-10-27）

- 用户WoS导出记录 W201，UT=WOS:001283918100017
