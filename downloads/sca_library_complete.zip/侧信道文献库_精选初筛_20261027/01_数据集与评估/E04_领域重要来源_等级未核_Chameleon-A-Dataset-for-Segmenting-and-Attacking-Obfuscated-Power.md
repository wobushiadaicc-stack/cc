# E04｜Chameleon: A Dataset for Segmenting and Attacking Obfuscated Power Traces in Side-Channel Analysis

- **来源**：IACR Transactions on Cryptographic Hardware and Embedded Systems。
- **年份说明**：TCHES 2025。
- **作者**：Davide Galli; Giuseppe Chiari ; Davide Zoni。
- **正式入口**：[10.46586/tches.v2025.i3.389-412](https://doi.org/10.46586/tches.v2025.i3.389-412)。
- **收录状态**：按领域重要来源路线保留；正式发表已核，未声称中科院分区或本轮已核CCF级别。
- **阅读优先级 / 难度**：P1 / 中。
- **内容判断依据**：摘要初筛；未逐节精读或复现实验。
- **全文状态**：附英文全文（已验证可解析）。

## 为什么放在这里

真实硬件隐藏措施的数据集，包含运算分割标注。

## 阅读时要回答的问题

真实动态变频、延迟、混淆与人工Desync实验有什么不同？

## 前置知识

CPA/ASCAD与统计指标；信息论条目需熵、互信息和统计估计基础。

## 本地全文

[E04_领域重要来源_等级未核_Chameleon-A-Dataset-for-Segmenting-and-Attacking-Obfuscated-Power.pdf](E04_领域重要来源_等级未核_Chameleon-A-Dataset-for-Segmenting-and-Attacking-Obfuscated-Power.pdf)（24 页）。

## 原文摘要（供检索与初筛）

Side-channel attacks exploit unintended information leakage emitted by cryptographic devices to extract sensitive data. Hiding techniques are a cost-effective countermeasure designed to obfuscate the side-channel leakage and hinder these attacks. Available open datasets rely on artificial models to simulate hiding effects, preventing a realistic assessment of these countermeasures and, thus, leaving a pressing need for datasets offering real-world, obfuscated side-channel measurements. Chameleon introduces the first comprehensive dataset of real-world, obfuscated power traces collected from a RISC-V-based System-on-Chip. The traces are obfuscated using four state-of-the-art hiding techniques: dynamic frequency scaling, random delay, morphing, and chaffing. Chameleon captures real leakage deformations introduced by actual hardware implementations, making it a realistic and valuable tool for evaluating side-channel countermeasures. A key feature of Chameleon is its dual focus on the segmentation and attack stages of the side-channel analysis process. It is the first dataset designed to facilitate the challenging task of segmenting cryptographic operations from obfuscated traces, offering precise metadata that pinpoints the start and end of each operation. The high-quality metadata enables systematic research into segmentation techniques, a critical step often overlooked in previous datasets. Chameleon provides an essential platform for researchers to develop and test new side-channel attacks, highlighting the vulnerabilities of current hiding techniques. By offering a more realistic assessment of countermeasure effectiveness, Chameleon is an invaluable tool for advancing the state-of-the-art in the side-channel evaluation.

## 题录证据（核验日：2026-10-27）

- 出版方页面：https://tches.iacr.org/index.php/TCHES/article/view/12221
