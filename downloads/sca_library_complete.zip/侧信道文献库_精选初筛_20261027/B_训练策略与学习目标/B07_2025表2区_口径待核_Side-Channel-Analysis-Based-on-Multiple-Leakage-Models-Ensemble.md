# B07｜Side-Channel Analysis Based on Multiple Leakage Models Ensemble

- **来源**：IEEE Transactions on Dependable and Secure Computing。
- **年份说明**：2026。
- **作者**：Wubiao Gao; Juesong Cai; Yingjian Yan; Pengfei Guo; Tao Hu。
- **正式入口**：[10.1109/tdsc.2025.3641165](https://doi.org/10.1109/tdsc.2025.3641165)。
- **收录状态**：按所提供表暂符合一区/二区，待确认口径。
- **阅读优先级 / 难度**：P2 / 中。
- **内容判断依据**：摘要初筛；未逐节精读或复现实验。
- **全文状态**：全文待补。

## 为什么放在这里

集成多个泄漏模型，比较标签/泄漏假设的互补性。

## 阅读时要回答的问题

集成是否只因用了更多模型和预算？不同泄漏标签的概率怎样合并？

## 前置知识

训练/验证/攻击数据划分、交叉熵和GE；优化/对比学习条目建议先补相应基础。

## 原文摘要（供检索与初筛）

In an era where cryptographic devices are widely used, research on Side-Channel Analysis (SCA) has attracted significant attention. While Deep Learning-based SCA (DLSCA) demonstrates notable advantages with the rapid development of deep learning, its performance remains constrained by reliance on single leakage model, leading to inefficient attacks and inadequate information utilization-particularly in grey-box scenarios where optimal leakage point identification proves challenging. Traditional ensemble methods attempting multiple leakage points combination are limited to either homogeneous models or manual feature fusion, failing to address the collaborative optimization of heterogeneous leakage features. To overcome these limitations, we propose a side-channel analysis framework based on multiple leakage models ensemble. This approach defines the training process of neural networks under different leakage models as base learners and employs Bagging ensemble learning to combine complementary leakage characteristics from heterogeneous leakage models. Thereby, it collaboratively optimizes multi-dimensional physical leakage features, significantly improving the efficiency and robustness of key recovery. Furthermore, based on information entropy and Jensen's inequality, we rigorously prove that the predictive distribution of the ensemble model more closely approximates the true key distribution, providing theoretical support for multiple models ensemble. Experimental results show that the proposed modular ensemble framework supports flexible combinations of arbitrary leakage models and exhibits excellent generalization capability and stability across different platforms and adversarial environments.

## 题录证据（核验日：2026-10-27）

- 用户WoS导出记录 W259，UT=WOS:001714509500048
- Crossref正式DOI元数据：https://api.crossref.org/works/10.1109/tdsc.2025.3641165

Crossref日期字段：`{"published": {"date-parts": [[2026, 3]]}, "published-print": {"date-parts": [[2026, 3]]}}`。年份显示以本页“年份说明”区分会议届次、在线年和卷年。

## 2025分区表匹配补充（2026-10-29）

用户提供2025表，第8572行；原表未注明大类/小类，未独立核实官方来源；表中分区：2区。此结果不是官方大类分区核实结论。
