# F06｜Methodology for Efficient CNN Architectures in Profiling Attacks

- **来源**：IACR Transactions on Cryptographic Hardware and Embedded Systems。
- **年份说明**：TCHES 2020(1)。
- **作者**：Gabriel Zaid; Lilian Bossuet; Amaury Habrard; Alexandre Venelli。
- **正式入口**：[10.46586/tches.v2020.i1.1-36](https://doi.org/10.46586/tches.v2020.i1.1-36)。
- **收录状态**：基础阅读单列；不占近三年高等级核心名额。
- **阅读优先级 / 难度**：P1 / 中。
- **内容判断依据**：摘要初筛；未逐节精读或复现实验。
- **全文状态**：附英文全文（已验证可解析）。

## 为什么放在这里

系统构建高效CNN架构，作为后续新结构的基础参照。

## 阅读时要回答的问题

性能来自架构、预处理还是调参？小网络为何可能优于大网络？

## 前置知识

按优先阅读路线推进；已有知识可快速复习。

## 本地全文

[F06_经典例外_Methodology-for-Efficient-CNN-Architectures-in-Profiling-Attacks.pdf](F06_经典例外_Methodology-for-Efficient-CNN-Architectures-in-Profiling-Attacks.pdf)（36 页）。

## 原文摘要（供检索与初筛）

The side-channel community recently investigated a new approach, based on deep learning, to significantly improve profiled attacks against embedded systems. Previous works have shown the benefit of using convolutional neural networks (CNN) to limit the effect of some countermeasures such as desynchronization. Compared with template attacks, deep learning techniques can deal with trace misalignment and the high dimensionality of the data. Pre-processing is no longer mandatory. However, the performance of attacks depends to a great extent on the choice of each hyperparameter used to configure a CNN architecture. Hence, we cannot perfectly harness the potential of deep neural networks without a clear understanding of the network’s inner-workings. To reduce this gap, we propose to clearly explain the role of each hyperparameters during the feature selection phase using some specific visualization techniques including Weight Visualization, Gradient Visualization and Heatmaps. By highlighting which features are retained by filters, heatmaps come in handy when a security evaluator tries to interpret and understand the efficiency of CNN. We propose a methodology for building efficient CNN architectures in terms of attack efficiency and network complexity, even in the presence of desynchronization. We evaluate our methodology using public datasets with and without desynchronization. In each case, our methodology outperforms the previous state-of-the-art CNN models while significantly reducing network complexity. Our networks are up to 25 times more efficient than previous state-of-the-art while their complexity is up to 31810 times smaller. Our results show that CNN networks do not need to be very complex to perform well in the side-channel context.

## 题录证据（核验日：2026-10-27）

- Crossref正式DOI元数据：https://api.crossref.org/works/10.46586/tches.v2020.i1.1-36

Crossref日期字段：`{"published": {"date-parts": [[2019, 11, 19]]}, "published-online": {"date-parts": [[2019, 11, 19]]}}`。年份显示以本页“年份说明”区分会议届次、在线年和卷年。
