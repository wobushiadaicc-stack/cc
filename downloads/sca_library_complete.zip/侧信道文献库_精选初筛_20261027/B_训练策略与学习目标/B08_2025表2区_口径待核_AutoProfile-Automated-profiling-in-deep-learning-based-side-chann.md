# B08｜AutoProfile: Automated profiling in deep learning-based side-channel analysis

- **来源**：Neural Networks。
- **年份说明**：Neural Networks 2026卷年。
- **作者**：Yimeng Chen; Bo Wang; Changshan Su; Ao Li; Gen Li; Yuxing Tang; An Wang。
- **正式入口**：[10.1016/j.neunet.2025.108009](https://doi.org/10.1016/j.neunet.2025.108009)。
- **收录状态**：按所提供表暂符合一区/二区，待确认口径。
- **阅读优先级 / 难度**：P2 / 中。
- **内容判断依据**：摘要初筛；未逐节精读或复现实验。
- **全文状态**：全文待补。

## 为什么放在这里

AutoProfile：针对侧信道任务定制贝叶斯超参数优化。

## 阅读时要回答的问题

搜索空间、总预算、验证集指标是否与基线一致？

## 前置知识

训练/验证/攻击数据划分、交叉熵和GE；优化/对比学习条目建议先补相应基础。

## 原文摘要（供检索与初筛）

Side-channel analysis (SCA) capitalizes on unintentionally leaked information to extract sensitive data from cryptographic systems. Over recent years, the side-channel community has exhibited a notable surge in interest towards deep learning (DL) techniques. However, the challenge of constructing appropriate networks has been highlighted. This paper presents a novel methodology named AutoProfile to enhance the efficacy of DL-based profiling attack on robust cryptographic system. AutoProfile customizes two core components of Bayesian optimization for SCA: the modeling strategy and acquisition function. The performance of AutoProfile is assessed on publicly available datasets that consist of real side-channel measurements. The experimental results showcase substantial improvements over the state-of-the-art method, achieving an average performance enhancement of 78.4%. Notably, for more robust targets that employ a combination of masking, random delay and key variation countermeasures, AutoProfile delivers the most significant performance boost. It reduces the number of traces required from the thousands, as typically needed by state-of-the-art methods, to merely dozens to break the targets. Furthermore, the experiments show that AutoProfile is notably faster than baseline methods in identifying effective networks over all tested SCA datasets.

## 题录证据（核验日：2026-10-27）

- 用户WoS导出记录 W034，UT=WOS:001562575000001
- Crossref正式DOI元数据：https://api.crossref.org/works/10.1016/j.neunet.2025.108009

Crossref日期字段：`{"published": {"date-parts": [[2026, 1]]}, "published-print": {"date-parts": [[2026, 1]]}}`。年份显示以本页“年份说明”区分会议届次、在线年和卷年。

## 2025分区表匹配补充（2026-10-29）

用户提供2025表，第15894行；原表未注明大类/小类，未独立核实官方来源；表中分区：2区。此结果不是官方大类分区核实结论。
