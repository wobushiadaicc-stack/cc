# A01｜EstraNet: An Efficient Shift-Invariant Transformer Network for Side-Channel Analysis

- **来源**：IACR Transactions on Cryptographic Hardware and Embedded Systems。
- **年份说明**：TCHES 2024(1)。
- **作者**：Suvadeep Hajra; Siddhartha Chowdhury; Debdeep Mukhopadhyay。
- **正式入口**：[10.46586/tches.v2024.i1.336-374](https://doi.org/10.46586/tches.v2024.i1.336-374)。
- **收录状态**：按领域重要来源路线保留；正式发表已核，未声称中科院分区或本轮已核CCF级别。
- **阅读优先级 / 难度**：P1 / 中。
- **内容判断依据**：摘要初筛；未逐节精读或复现实验。
- **全文状态**：附英文全文（已验证可解析）。

## 为什么放在这里

平移不变Transformer：把长迹计算成本和错位处理放到同一结构里研究。

## 阅读时要回答的问题

模型在哪一步处理错位？与CNN的训练预算、裁剪范围是否一致？

## 前置知识

CPA、ASCAD标签与GE；CNN基本结构。解释性和双曲表示另需对应数学基础。

## 本地全文

[A01_领域重要来源_等级未核_EstraNet-An-Efficient-Shift-Invariant-Transformer-Network-for-Sid.pdf](A01_领域重要来源_等级未核_EstraNet-An-Efficient-Shift-Invariant-Transformer-Network-for-Sid.pdf)（39 页）。

## 作者代码 / 数据入口

https://github.com/suvadeep-iitb/EstraNet

入口来自论文、官方摘要或既有作者项目；不代表已运行代码或下载数据。

## 原文摘要（供检索与初筛）

Deep Learning (DL) based Side-Channel Analysis (SCA) has been extremely popular recently. DL-based SCA can easily break implementations protected by masking countermeasures. DL-based SCA has also been highly successful against implementations protected by various trace desynchronization-based countermeasures like random delay, clock jitter and shuffling. Over the years, many DL models have been explored to perform SCA. Recently, Transformer Network (TN) based model has also been introduced for SCA. Though the previously introduced TN-based model is successful against implementations jointly protected by masking and random delay countermeasures, it is not scalable to long traces (having a length greater than a few thousand) due to its quadratic time and memory complexity. This work proposes a novel shift-invariant TN-based model with linear time and memory complexity. he contributions of the work are two-fold. First, we introduce a novel TN-based model called EstraNet for SCA. EstraNet has linear time and memory complexity in trace length, significantly improving over the previously proposed TN-based model’s quadratic time and memory cost. EstraNet is also shift-invariant, making it highly effective against countermeasures like random delay and clock jitter. Secondly, we evaluated EstraNet on three SCA datasets of masked implementations with random delay and clock jitter effect. Our experimental results show that EstraNet significantly outperforms several benchmark models, demonstrating up to an order of magnitude reduction in the number of attack traces required to reach guessing entropy 1.

## 题录证据（核验日：2026-10-27）

- 出版方页面：https://tches.iacr.org/index.php/TCHES/article/view/11255
