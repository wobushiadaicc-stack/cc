# F08｜Pay Attention to Raw Traces: A Deep Learning Architecture for End-to-End Profiling Attacks

- **来源**：IACR Transactions on Cryptographic Hardware and Embedded Systems。
- **年份说明**：TCHES 2021(3)。
- **作者**：Xiangjun Lu; Chi Zhang; Pei Cao; Dawu Gu; Haining Lu。
- **正式入口**：[10.46586/tches.v2021.i3.235-274](https://doi.org/10.46586/tches.v2021.i3.235-274)。
- **收录状态**：基础阅读单列；不占近三年高等级核心名额。
- **阅读优先级 / 难度**：P2 / 中。
- **内容判断依据**：摘要初筛；未逐节精读或复现实验。
- **全文状态**：附英文全文（已验证可解析）。

## 为什么放在这里

长原始迹端到端注意力攻击，是EstraNet之前的阅读铺垫。

## 阅读时要回答的问题

不再手工裁剪PoI后，模型成本和攻击者能力发生了什么变化？

## 前置知识

按优先阅读路线推进；已有知识可快速复习。

## 本地全文

[F08_经典例外_Pay-Attention-to-Raw-Traces-A-Deep-Learning-Architecture-for-End.pdf](F08_经典例外_Pay-Attention-to-Raw-Traces-A-Deep-Learning-Architecture-for-End.pdf)（40 页）。

## 原文摘要（供检索与初筛）

With the renaissance of deep learning, the side-channel community also notices the potential of this technology, which is highly related to the profiling attacks in the side-channel context. Many papers have recently investigated the abilities of deep learning in profiling traces. Some of them also aim at the countermeasures (e.g., masking) simultaneously. Nevertheless, so far, all of these papers work with an (implicit) assumption that the number of time samples in raw traces can be reduced before the profiling, i.e., the position of points of interest (PoIs) can be manually located. This is arguably the most challenging part of a practical black-box analysis targeting an implementation protected by masking. Therefore, we argue that to fully utilize the potential of deep learning and get rid of any manual intervention, the end-to-end profiling directly mapping raw traces to target intermediate values is demanded.In this paper, we propose a neural network architecture that consists of encoders, attention mechanisms and a classifier, to conduct the end-to-end profiling. The networks built by our architecture could directly classify the traces that contain a large number of time samples (i.e., raw traces without manual feature extraction) while whose underlying implementation is protected by masking. We validate our networks on several public datasets, i.e., DPA contest v4 and ASCAD, where over 100,000 time samples are directly used in profiling. To our best knowledge, we are the first that successfully carry out end-to-end profiling attacks. The results on the datasets indicate that our networks could get rid of the tricky manual feature extraction. Moreover, our networks perform even systematically better (w.r.t. the number of traces in attacks) than those trained on the reduced traces. These validations imply our approach is not only a first but also a concrete step towards end-to-end profiling attacks in the side-channel context.

## 题录证据（核验日：2026-10-27）

- Crossref正式DOI元数据：https://api.crossref.org/works/10.46586/tches.v2021.i3.235-274

Crossref日期字段：`{"published": {"date-parts": [[2021, 7, 9]]}, "published-online": {"date-parts": [[2021, 7, 9]]}}`。年份显示以本页“年份说明”区分会议届次、在线年和卷年。
