# D01｜A Second Look at the Portability of Deep Learning Side-Channel Attacks over EM Traces

- **来源**：The 27th International Symposium on Research in Attacks, Intrusions and Defenses。
- **年份说明**：RAID 2024。
- **作者**：Mabon Ninan; Evan Nimmo; Shane Reilly; Channing Smith; Wenhai Sun; Boyang Wang; John M. Emmert。
- **正式入口**：[10.1145/3678890.3678900](https://doi.org/10.1145/3678890.3678900)。
- **收录状态**：按领域重要来源路线保留；正式发表已核，未声称中科院分区或本轮已核CCF级别。
- **阅读优先级 / 难度**：P1 / 中。
- **内容判断依据**：摘要初筛；未逐节精读或复现实验。
- **全文状态**：全文待补。

## 为什么放在这里

CrossEM：把设备、密钥、探头位置差异拆开评估，是泛化入门主线。

## 阅读时要回答的问题

论文指出的两类乐观评估陷阱是什么？每个对照控制了哪些变量？

## 前置知识

建模攻击与源域/目标域；先区分跨设备、跨采集、跨算法实现和人工扰动。

## 作者代码 / 数据入口

https://github.com/UCdasec/CrossEM

入口来自论文、官方摘要或既有作者项目；不代表已运行代码或下载数据。

## 原文摘要（供检索与初筛）

Deep learning side-channel attacks can recover encryption keys on a target by analyzing power consumption or electromagnetic (EM) signals. However, they are less portable when there are domain shifts between training and test data. While existing studies have shown that pre-processing and unsupervised domain adaptation can enhance the portability of deep learning side-channel attacks given domain shifts over EM traces, the findings are limited to easy targets (e.g. 8-bit microcontrollers). In this paper, we investigate the portability of deep learning side-channel attacks over EM traces acquired from more challenging targets, including 32-bit microcontrollers and EM traces with random delay. We study domain shifts introduced by the combination of hardware variations, distinct keys, and inconsistent probe locations between two targets. In addition, we perform comparative analyses of multiple existing (and new) pre-processing and unsupervised domain adaptation methods. We conduct a series of comprehensive experiments and derive three main observations. (1) Pre-processing and unsupervised domain adaptation methods can enhance the portability of deep learning side-channel attacks over more challenging targets. (2) The effectiveness of each method, however, varies depending on the target and probe locations in use. In other words, observations of a method on easy targets do not necessarily generalize to challenging targets. (3) None of the methods can constantly outperform others. Moreover, we highlight two types of pitfalls that could lead to over-optimistic attack results in cross-device evaluations. We also contribute a large-scale public dataset (with 3 million EM traces from 9 probe locations over multiple targets) for benchmarking and reproducibility of side-channel attacks tackling domain shifts over EM traces.

## 题录证据（核验日：2026-10-27）

- 用户WoS导出记录 W081，UT=WOS:001331944800039
- Crossref正式DOI元数据：https://api.crossref.org/works/10.1145/3678890.3678900

Crossref日期字段：`{"published": {"date-parts": [[2024, 9, 30]]}, "published-print": {"date-parts": [[2024, 9, 30]]}, "published-online": {"date-parts": [[2024, 9, 30]]}}`。年份显示以本页“年份说明”区分会议届次、在线年和卷年。
