# F02｜Correlation Power Analysis with a Leakage Model

- **来源**：Lecture Notes in Computer Science / Cryptographic Hardware and Embedded Systems - CHES 2004。
- **年份说明**：CHES 2004。
- **作者**：Eric Brier; Christophe Clavier; Francis Olivier。
- **正式入口**：[10.1007/978-3-540-28632-5_2](https://doi.org/10.1007/978-3-540-28632-5_2)。
- **收录状态**：基础阅读单列；不占近三年高等级核心名额。
- **阅读优先级 / 难度**：P1 / 入门。
- **内容判断依据**：仅题录/既有说明；需补摘要或全文复筛。
- **全文状态**：全文待补。

## 为什么放在这里

CPA经典：连接密钥猜测、中间值、HW/HD模型与相关性。

## 阅读时要回答的问题

怎样从每个猜测的统计分数得到正确密钥排名？

## 前置知识

按优先阅读路线推进；已有知识可快速复习。

## 内容核验缺口

本轮未取得可核验的完整摘要/正文；中文定位只用于规划阅读，不能作为已证实的方法细节或实验结论。

## 题录证据（核验日：2026-10-27）

- Crossref正式DOI元数据：https://api.crossref.org/works/10.1007/978-3-540-28632-5_2

Crossref日期字段：`{"published": {"date-parts": [[2004]]}, "published-print": {"date-parts": [[2004]]}}`。年份显示以本页“年份说明”区分会议届次、在线年和卷年。
