# E03｜Multivariate Leakage Detection

- **来源**：IACR Transactions on Cryptographic Hardware and Embedded Systems。
- **年份说明**：TCHES 2026；补回缺失题名；全文待补。
- **作者**：Aakash Chowdhury; Elisabeth Oswald。
- **正式入口**：[10.46586/tches.v2026.i2.296-324](https://doi.org/10.46586/tches.v2026.i2.296-324)。
- **收录状态**：按领域重要来源路线保留；正式发表已核，未声称中科院分区或本轮已核CCF级别。
- **阅读优先级 / 难度**：P2 / 高。
- **内容判断依据**：摘要初筛；未逐节精读或复现实验。
- **全文状态**：全文待补。

## 为什么放在这里

多变量泄漏检测：用错误率检验深度学习与传统统计检测的差异。

## 阅读时要回答的问题

假阳性和假阴性怎样控制？检测到泄漏是否就意味着能够恢复密钥？

## 前置知识

CPA/ASCAD与统计指标；信息论条目需熵、互信息和统计估计基础。

## 原文摘要（供检索与初筛）

Leakage detection tests are designed to determine if side channel traces are data (or key) dependent. Non-specific leakage detection tests are particularly valuable in the early stages of an evaluation, because they only make minimal assumptions about the leakage and the implementation that is being tested. The most important property of a detection test is its ability to detect true leaks (minimise the rate of false negatives) whilst not alerting incorrectly (minimise the rate of false positives). A detection test is “better” if, for a fixed rate of false positives, it achieves a smaller rate of false negatives. A recent experimental study, which compared a deep learning based approach to classical statistics, suggests that deep learning might be superior over classical statistics for multivariate detection, missing however a thorough exploration of error rates.Classical statistical methods progressed, and in this paper, we explore a generalisation of Pearson correlation, called distance correlation (covariance), which captures nonlinear dependencies (unlike Pearson correlation), for the purpose of non-specific leakage detection. We conduct experiments using several real-world data-sets from software and hardware implementations of commonly used block ciphers (AES, PRESENT, ASCON) with and without countermeasures (hiding and masking). We find that the recently proposed deep learning detection technique does not reliably decrease its false negative rate with more traces. Other multivariate methods fail to detect anything in some of the scenarios. The most robust detection techniques are classical univariate statistics using appropriate multiplicity corrections, and the multivariate distance covariance test. Classical statistical methods require minimal configuration, and therefore, give the evaluator the freedom to not worry about properties of traces and configuring deep net architectures, which makes them a highly attractive option for practical use.

## 题录证据（核验日：2026-10-27）

- 用户WoS导出记录 W494，UT=RC:169301284_S24
- Crossref正式DOI元数据：https://api.crossref.org/works/10.46586/tches.v2026.i2.296-324

Crossref日期字段：`{"published": {"date-parts": [[2026, 4, 23]]}, "published-online": {"date-parts": [[2026, 4, 23]]}}`。年份显示以本页“年份说明”区分会议届次、在线年和卷年。
