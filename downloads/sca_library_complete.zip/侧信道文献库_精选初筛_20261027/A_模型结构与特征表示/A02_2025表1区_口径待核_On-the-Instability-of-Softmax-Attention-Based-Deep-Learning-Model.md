# A02｜On the Instability of Softmax Attention-Based Deep Learning Models in Side-Channel Analysis

- **来源**：IEEE Transactions on Information Forensics and Security。
- **年份说明**：正式卷年2024；DOI含2023不等于卷年。
- **作者**：Suvadeep Hajra; Manaar Alam; Sayandeep Saha; Stjepan Picek; Debdeep Mukhopadhyay。
- **正式入口**：[10.1109/tifs.2023.3326667](https://doi.org/10.1109/tifs.2023.3326667)。
- **收录状态**：按所提供表暂符合一区/二区，待确认口径。
- **阅读优先级 / 难度**：P1 / 中。
- **内容判断依据**：摘要初筛；未逐节精读或复现实验。
- **全文状态**：全文待补。

## 为什么放在这里

研究长迹上Softmax注意力训练不稳定，适合与课题组混合注意力CNN对读。

## 阅读时要回答的问题

多头注意力与归一化分别起什么作用？性能改善是否来自训练更稳定？

## 前置知识

CPA、ASCAD标签与GE；CNN基本结构。解释性和双曲表示另需对应数学基础。

## 原文摘要（供检索与初筛）

In side-channel analysis (SCA), Points-of-Interest (PoIs), i.e., the informative sample points remain sparsely scattered across the whole side-channel trace. Several works in the SCA literature have demonstrated that the attack efficacy could be significantly improved by combining information from the sparsely occurring PoIs. In Deep Learning (DL), a common approach for combining the information from the sparsely occurring PoIs is softmax attention. This work studies the training instability of the softmax attention-based CNN models on long traces. We show that the softmax attention-based CNN model incurs an unstable training problem when applied to longer traces (e.g., traces having a length greater than $10K$ sample points). We also explore the use of batch normalization and multi-head softmax attention to make the CNN models stable. Our results show that the use of a large number of batch normalization layers and/or multi-head softmax attention (replacing the vanilla softmax attention) can make the models significantly more stable, resulting in better attack efficacy. Moreover, we found our models to achieve similar or better results (up to 85% reduction in the minimum number of the required traces to reach the guessing entropy 1) than the state-of-the-art results on several synchronized and desynchronized datasets. Finally, by plotting the loss surface of the DL models, we demonstrate that using multi-head softmax attention instead of vanilla softmax attention in the CNN models can make the loss surface significantly smoother.

## 题录证据（核验日：2026-10-27）

- 用户WoS导出记录 W119，UT=WOS:001123966000017
- Crossref正式DOI元数据：https://api.crossref.org/works/10.1109/tifs.2023.3326667

Crossref日期字段：`{"published": {"date-parts": [[2024]]}, "published-print": {"date-parts": [[2024]]}}`。年份显示以本页“年份说明”区分会议届次、在线年和卷年。

## 2025分区表匹配补充（2026-10-29）

用户提供2025表，第8593行；原表未注明大类/小类，未独立核实官方来源；表中分区：1区。此结果不是官方大类分区核实结论。
