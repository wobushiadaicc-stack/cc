# F07｜Remove Some Noise: On Pre-processing of Side-channel Measurements with Autoencoders

- **来源**：IACR Transactions on Cryptographic Hardware and Embedded Systems。
- **年份说明**：TCHES 2020(4)。
- **作者**：Lichao Wu; Stjepan Picek。
- **正式入口**：[10.13154/tches.v2020.i4.389-415](https://doi.org/10.13154/tches.v2020.i4.389-415)。
- **收录状态**：基础阅读单列；不占近三年高等级核心名额。
- **阅读优先级 / 难度**：P1 / 中。
- **内容判断依据**：摘要初筛；未逐节精读或复现实验。
- **全文状态**：附英文全文（已验证可解析）。

## 为什么放在这里

去噪自编码器基础，连接传统预处理和生成式方法。

## 阅读时要回答的问题

输入/目标迹如何构造？对齐噪声、测量噪声与掩码是否应分别讨论？

## 前置知识

按优先阅读路线推进；已有知识可快速复习。

## 本地全文

[F07_经典例外_Remove-Some-Noise-On-Pre-processing-of-Side-channel-Measurements.pdf](F07_经典例外_Remove-Some-Noise-On-Pre-processing-of-Side-channel-Measurements.pdf)（27 页）。

## 作者代码 / 数据入口

https://github.com/AISyLab/Denoising-autoencoder

入口来自论文、官方摘要或既有作者项目；不代表已运行代码或下载数据。

## 原文摘要（供检索与初筛）

In the profiled side-channel analysis, deep learning-based techniques proved to be very successful even when attacking targets protected with countermeasures. Still, there is no guarantee that deep learning attacks will always succeed. Various countermeasures make attacks significantly more complex, and such countermeasures can be further combined to make the attacks even more challenging. An intuitive solution to improve the performance of attacks would be to reduce the effect of countermeasures. This paper investigates whether we can consider certain types of hiding countermeasures as noise and then use a deep learning technique called the denoising autoencoder to remove that noise. We conduct a detailed analysis of six different types of noise and countermeasures separately or combined and show that denoising autoencoder improves the attack performance significantly.

## 题录证据（核验日：2026-10-27）

- 出版方页面：https://tches.iacr.org/index.php/TCHES/article/view/8688
