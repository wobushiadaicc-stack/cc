# B06｜LD-PA: Distilling Univariate Leakage for Deep Learning-Based Profiling Attacks

- **来源**：IEEE Transactions on Information Forensics and Security。
- **年份说明**：TIFS 2025卷年。
- **作者**：Chong Xiao; Ming Tang; Sengim Karayalcin; Wei Cheng。
- **正式入口**：[10.1109/tifs.2024.3490782](https://doi.org/10.1109/tifs.2024.3490782)。
- **收录状态**：按所提供表暂符合一区/二区，待确认口径。
- **阅读优先级 / 难度**：P2 / 中高。
- **内容判断依据**：摘要初筛；未逐节精读或复现实验。
- **全文状态**：全文待补。

## 为什么放在这里

LD-PA：通过单变量参考泄漏指导多变量表示学习。

## 阅读时要回答的问题

参考泄漏怎样获得？这种额外知识在你的实验条件下是否成立？

## 前置知识

训练/验证/攻击数据划分、交叉熵和GE；优化/对比学习条目建议先补相应基础。

## 原文摘要（供检索与初筛）

The deep learning-based profiling attacks have received significant attention for their potential against masking-protected devices. Currently, additional capabilities like exploiting only a segment of the side-channel traces or having knowledge of the specific countermeasure scheme have been granted to attackers during the profiling phase. In case either capability is removed, a practical profiling attack faces great difficulty and complexity. To address this challenge, we propose an efficient and scheme-agnostic Leakage Distillation-based Profiling Attack (LD-PA). By distilling univariate leakage from a reference, we can train an encoder that extracts multivariate leakage from raw traces and transforms it into an effective representation (transitional leakage). An indirect connection between multivariate leakage and the target variable is established by bridging through the transitional leakage, thereby facilitating the inference of leaked values. Remarkably, LD-PA achieves successful attacks on multiple public datasets using a simple multilayer perceptron (MLP) without necessitating an exhaustive hyperparameter search, while its performance is competitive with state-of-the-art methods. Simultaneously, we delve into the nature of transitional leakage, confirming the existence of combined leakage. This, in turn, validates that the guidance from univariate leakage references aids in the combination of multivariate leakage. Besides that, each component of the multivariate leakage is extracted and stacked in a highly aligned manner. Moreover, we explored several factors impacting LD-PA performance, covering scenarios with limited profiling traces, noisy references, alternative references, and hyperparameter tuning.

## 题录证据（核验日：2026-10-27）

- 用户WoS导出记录 W168，UT=WOS:001386718900023
- Crossref正式DOI元数据：https://api.crossref.org/works/10.1109/tifs.2024.3490782

Crossref日期字段：`{"published": {"date-parts": [[2025]]}, "published-print": {"date-parts": [[2025]]}}`。年份显示以本页“年份说明”区分会议届次、在线年和卷年。

## 2025分区表匹配补充（2026-10-29）

用户提供2025表，第8593行；原表未注明大类/小类，未独立核实官方来源；表中分区：1区。此结果不是官方大类分区核实结论。
