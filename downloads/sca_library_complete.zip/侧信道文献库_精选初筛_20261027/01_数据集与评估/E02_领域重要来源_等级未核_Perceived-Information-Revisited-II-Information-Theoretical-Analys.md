# E02｜Perceived Information Revisited II: Information-Theoretical Analysis of Deep-Learning Based Side-Channel Attacks

- **来源**：IACR Transactions on Cryptographic Hardware and Embedded Systems。
- **年份说明**：TCHES 2025(1)，在线2024-12；不按WoS PY=2024误记卷年。
- **作者**：Akira Ito; Rei Ueno; Naofumi Homma。
- **正式入口**：[10.46586/tches.v2025.i1.450-474](https://doi.org/10.46586/tches.v2025.i1.450-474)。
- **收录状态**：按领域重要来源路线保留；正式发表已核，未声称中科院分区或本轮已核CCF级别。
- **阅读优先级 / 难度**：P2 / 高。
- **内容判断依据**：摘要初筛；未逐节精读或复现实验。
- **全文状态**：附英文全文（已验证可解析）。

## 为什么放在这里

LPI与信息论攻击界：解释潜在泄漏信息和实际恢复性能的区别。

## 阅读时要回答的问题

理论上界是否可达到？互信息估计的误差会如何影响解释？

## 前置知识

CPA/ASCAD与统计指标；信息论条目需熵、互信息和统计估计基础。

## 本地全文

[E02_领域重要来源_等级未核_Perceived-Information-Revisited-II-Information-Theoretical-Analys.pdf](E02_领域重要来源_等级未核_Perceived-Information-Revisited-II-Information-Theoretical-Analys.pdf)（25 页）。

## 原文摘要（供检索与初筛）

Previous studies on deep-learning-based side-channel attacks (DL-SCAs) have shown that traditional performance evaluation metrics commonly used in DL, like accuracy and F1 score, are not effective in evaluating DL-SCA performance. Therefore, some previous studies have proposed new alternative metrics for evaluating the performance of DL-SCAs. Notably, perceived information (PI) and effective perceived information (EPI) are major metrics based on information theory. While it has been experimentally confirmed that these metrics can give the attack success rate (SR) for DL-SCAs, their theoretical validity remains unclear.In this paper, we propose a new theoretically valid performance evaluation metric called latent perceived information (LPI), which serves as an alternative to the existing metrics. LPI is defined as the mutual information between the output of the feature extractor of a neural network (NN) model and the intermediate value, representing the potential attack performance of the trained model. First, we prove that LPI provides an upper bound on the SR of a DL-SCA by modeling and formulating DL-SCA as a communication channel. Additionally, we clarify the conditions under which PI and EPI theoretically provide an upper bound on the SR from the perspective of LPI. For practical computation of LPI, we present two methods. One utilizes the Kraskov (KSG) estimator, a common mutual information estimator, and the other is based on logistic regression. While the KSG estimator is computationally intensive, it yields accurate LPI values. In contrast, the logistic regression is faster but provides a lower bound for LPI. Through experimental attacks on AES software and hardware implementations with masking countermeasures, we demonstrate that the LPI values estimated by these two methods are significantly similar, indicating the reliability and soundness of our proposed estimation techniques. Furthermore, we show that, by using the logistic regression as a classifier, we can significantly improve the attack performance of the trained model when the difference between the SR upper bound by the LPI and its actual SR is large. This indicates that LPI represents the potential for performance improvement in the trained model. Therefore, our study contributes to optimizing the distinguisher for attack performance using the trained model.

## 题录证据（核验日：2026-10-27）

- 用户WoS导出记录 W528，UT=RC:148643244_S24
- Crossref正式DOI元数据：https://api.crossref.org/works/10.46586/tches.v2025.i1.450-474
- 出版方页面：https://tches.iacr.org/index.php/TCHES/article/view/11936

Crossref日期字段：`{"published": {"date-parts": [[2024, 12, 9]]}, "published-online": {"date-parts": [[2024, 12, 9]]}}`。年份显示以本页“年份说明”区分会议届次、在线年和卷年。
