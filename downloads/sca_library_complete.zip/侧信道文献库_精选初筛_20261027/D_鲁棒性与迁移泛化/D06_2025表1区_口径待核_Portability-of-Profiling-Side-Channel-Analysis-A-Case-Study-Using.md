# D06｜Portability of Profiling Side-Channel Analysis: A Case Study Using Adjustable Implementations of Block Ciphers

- **来源**：IEEE Transactions on Information Forensics and Security。
- **年份说明**：2026。
- **作者**：Di Li; Chun Li; Yufeng Tang; Yupeng Zhang; Zheng Gong。
- **正式入口**：[10.1109/tifs.2026.3651997](https://doi.org/10.1109/tifs.2026.3651997)。
- **收录状态**：按所提供表暂符合一区/二区，待确认口径。
- **阅读优先级 / 难度**：P3 / 高。
- **内容判断依据**：摘要初筛；未逐节精读或复现实验。
- **全文状态**：全文待补。

## 为什么放在这里

从可调整分组密码实现出发分析建模攻击可迁移性。

## 阅读时要回答的问题

算法实现变化与物理设备变化如何分开？何时需要修改泄漏模型？

## 前置知识

建模攻击与源域/目标域；先区分跨设备、跨采集、跨算法实现和人工扰动。

## 原文摘要（供检索与初筛）

Inconsistencies in manufacturing features, sampling settings, and cryptographic implementations amongst the profiling and target devices can lead to the failure of profiling side-channel analysis (SCA). Various techniques, such as preprocessing, multi-device training, and transfer learning, have been proposed to mitigate this portability problem in profiling SCA. However, many techniques of block ciphers, such as tweaks, key-dependent components, and customized elements, might have uncertain effects from the perspective of cryptographic implementations, requiring further insightful analysis on their impact on portability. This paper investigates the portability of profiling SCA from a case study using adjustable implementations of block ciphers. First, we theoretically analyze the variation in leakage distribution under adjustable implementations. To support our theoretical results, a dataset of deep-learning SCA is built from AES, Pilsung, and Skinny. Specifically, we reveal how to reverse the parameterized components and recover the key from these adjustable implementations. According to our experiment on an 8-bit AVR microcontroller, the computational complexities of the attacks based on our model are less than $9\times 2<^>{16}$ within 4500 traces. Moreover, the effectiveness of our proposed method is demonstrated under the combinatorial effect with adjustable implementations and device characteristics. Our case study provides insights into the results of adjustable implementations of block ciphers, which strengthens both the theoretical and practical understanding of the portability of profiling SCA.

## 题录证据（核验日：2026-10-27）

- 用户WoS导出记录 W379，UT=WOS:001663375400004
- Crossref正式DOI元数据：https://api.crossref.org/works/10.1109/tifs.2026.3651997

Crossref日期字段：`{"published": {"date-parts": [[2026]]}, "published-print": {"date-parts": [[2026]]}}`。年份显示以本页“年份说明”区分会议届次、在线年和卷年。

## 2025分区表匹配补充（2026-10-29）

用户提供2025表，第8593行；原表未注明大类/小类，未独立核实官方来源；表中分区：1区。此结果不是官方大类分区核实结论。
