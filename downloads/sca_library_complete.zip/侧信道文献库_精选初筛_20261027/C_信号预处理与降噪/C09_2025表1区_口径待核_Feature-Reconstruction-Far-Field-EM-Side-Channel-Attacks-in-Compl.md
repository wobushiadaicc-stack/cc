# C09｜Feature Reconstruction: Far Field EM Side-Channel Attacks in Complex Environment

- **来源**：IEEE Transactions on Information Forensics and Security。
- **年份说明**：2025；交叉标签D，主归C以避免重复。
- **作者**：Huanyu Wang; Dalin He; Deng Tuo; Junnian Wang。
- **正式入口**：[10.1109/tifs.2025.3611788](https://doi.org/10.1109/tifs.2025.3611788)。
- **收录状态**：按所提供表暂符合一区/二区，待确认口径。
- **阅读优先级 / 难度**：P2 / 中高。
- **内容判断依据**：摘要初筛；未逐节精读或复现实验。
- **全文状态**：全文待补。

## 为什么放在这里

远场EM的特征重建：使用DAE与域适应处理距离和干扰导致的噪声。

## 阅读时要回答的问题

干净域与噪声域的数据如何配对？15米实验是否可迁移到其他设备与干扰？

## 前置知识

采样迹、SNR、GE和基本信号处理；先理解参考迹与攻击者能力。

## 原文摘要（供检索与初筛）

Far Field EM Side-Channel Attacks (FEM-SCAs) have emerged as a realistic security threat to widely deployed RF-integrated IoT edge devices. In mixed-signal chips, side-channel leakage may unintentionally couple with transmission signals and be emitted via the on-chip antenna, potentially allowing adversaries to extract sensitive information from the victim at long distances. However, in practical scenarios, far field EM traces captured at long distances usually suffer from noise and interference, which makes the attack less efficient or sometimes even unfeasible. In this paper, we propose a Domain-Adversarial ReFeature Nueral Network (DAR-NN) to facilitate "noisy-clean" adaptation for far field EM traces captured at long distances. By integrating a DAE model with two deep-learning classifiers as regularization terms, the proposed DAR-NN model can reconstruct features of traces obtained remotely in complex environments, thereby achieving a more efficient FEM-SCA. We first test our model by using a publicly available dataset and show that it is feasible to extract the AES key from 141 traces captured at 15 m distance to the victim, which is 58.7% more efficient than existing methods with 80% less profiling data. Afterwards, we set up a more complex experimental environment with a HackRF radio serving as an interference source. We show that the proposed model can still extract the key by using around 2K traces at 15 m even in the presence of 25% active interference, while the state-of-the-art model fails under same conditions.

## 题录证据（核验日：2026-10-27）

- 用户WoS导出记录 W156，UT=WOS:001586179900006
- Crossref正式DOI元数据：https://api.crossref.org/works/10.1109/tifs.2025.3611788

Crossref日期字段：`{"published": {"date-parts": [[2025]]}, "published-print": {"date-parts": [[2025]]}}`。年份显示以本页“年份说明”区分会议届次、在线年和卷年。

## 2025分区表匹配补充（2026-10-29）

用户提供2025表，第8593行；原表未注明大类/小类，未独立核实官方来源；表中分区：1区。此结果不是官方大类分区核实结论。
