# C01｜Side-Channel Attacks Based on Multi-Loss Regularized Denoising AutoEncoder

- **来源**：IEEE Transactions on Information Forensics and Security。
- **年份说明**：TIFS 2024卷年。
- **作者**：Fanliang Hu; Jian Shen; Pandi Vijayakumar。
- **正式入口**：[10.1109/tifs.2023.3343947](https://doi.org/10.1109/tifs.2023.3343947)。
- **收录状态**：按所提供表暂符合一区/二区，待确认口径。
- **阅读优先级 / 难度**：P1 / 中。
- **内容判断依据**：摘要初筛；未逐节精读或复现实验。
- **全文状态**：全文待补。

## 为什么放在这里

ML-DAE：联合多个损失保留时间相关性，直接对应课题组降噪路线。

## 阅读时要回答的问题

干净参考如何得到？SNR改善是否在固定下游攻击器上转化为GE/SR改善？

## 前置知识

采样迹、SNR、GE和基本信号处理；先理解参考迹与攻击者能力。

## 原文摘要（供检索与初筛）

Recently, researchers have leveraged the Denoising AutoEncoder (DAE) to reduce the noise in side-channel acquisitions (a.k.a. traces) that reduces the effectiveness of key recovery. Taking the ${L}2$ Loss (Mean Square Error, MSE) as the objective function of the DAE, it only aims to lessen the Euclidean Distance (ED) between the input and output, overlooking the Intra-Data Correlation (IDC) of the trace which includes the timing information. This paper proposes the Multi-Loss Regularized Denoising AutoEncoder (ML-DAE) framework to improve the generalization capability of the DAE. This framework consists of a shared DAE and Multiple Loss (ML) functions that aim to reduce the noise while preserving the excellent IDC of the output. During the training phase, to avoid issues of overfitting and a high number of training parameters, we pre-train the DAE using MSE and then initiate the ML-DAE which contains a multicore Partial Loss (PL) function with parameters transferred from the pre-trained DAE. During the testing phase, the outputs from the multicore PL are fused using an average pooling layer to yield the final predictions. The experiments on highly noisy datasets (XMEGA_ME, DPA_V2, and AES_GPU) and the masked dataset ASCAD demonstrate that ML-DAE achieves an SNR gain of at least four times, hence Deep-Learning based Side-Channel Attacks (DLSCAs) and Template Attacks (TA) with denoising pre-processing reduce of the number of traces needed to recover the key in the attack phase by more than 55%.

## 题录证据（核验日：2026-10-27）

- 用户WoS导出记录 W241，UT=WOS:001136791100012
- Crossref正式DOI元数据：https://api.crossref.org/works/10.1109/tifs.2023.3343947

Crossref日期字段：`{"published": {"date-parts": [[2024]]}, "published-print": {"date-parts": [[2024]]}}`。年份显示以本页“年份说明”区分会议届次、在线年和卷年。

## 2025分区表匹配补充（2026-10-29）

用户提供2025表，第8593行；原表未注明大类/小类，未独立核实官方来源；表中分区：1区。此结果不是官方大类分区核实结论。
