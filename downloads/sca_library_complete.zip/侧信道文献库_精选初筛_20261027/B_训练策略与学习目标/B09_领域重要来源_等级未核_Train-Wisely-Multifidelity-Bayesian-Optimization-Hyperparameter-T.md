# B09｜Train Wisely: Multifidelity Bayesian Optimization Hyperparameter Tuning in Deep Learning-Based Side-Channel Analysis

- **来源**：Lecture Notes in Computer Science / Selected Areas in Cryptography – SAC 2024。
- **年份说明**：SAC 2024会议；2025年章节，按2024会议年标注。
- **作者**：Trevor Yap; Shivam Bhasin; Léo Weissbart。
- **正式入口**：[10.1007/978-3-031-82841-6_12](https://doi.org/10.1007/978-3-031-82841-6_12)。
- **收录状态**：按领域重要来源路线保留；正式发表已核，未声称中科院分区或本轮已核CCF级别。
- **阅读优先级 / 难度**：P2 / 中。
- **内容判断依据**：摘要初筛；未逐节精读或复现实验。
- **全文状态**：全文待补。

## 为什么放在这里

Train Wisely：多保真贝叶斯优化，把调参预算作为明确实验变量。

## 阅读时要回答的问题

低预算任务能否预测高预算性能？新目标函数是否会偏好特定数据集？

## 前置知识

训练/验证/攻击数据划分、交叉熵和GE；优化/对比学习条目建议先补相应基础。

## 原文摘要（供检索与初筛）

Side-Channel Analysis (SCA) is critical in evaluating the security of cryptographic implementations. In recent years, the use of Deep Neural Networks (DNNs) in SCA has risen in popularity. However, DNNs consists of many hyperparameters and not every configuration of hyperparameters result in successful attack. Therefore, the search for DNN's hyperparameters poses a significant challenge, especially when resources are limited. In this work, we explore the efficacy of a multifidelity optimization technique known as Bayesian Optimization HyperBand (BOHB) in SCA. This introduces the notion of budget within SCA to encapsulate the idea of resources when tuning the hyperparmeters of the DNNs. Next, we proposed a new objective function called ge+ntge, which could be incorporated into any Bayesian Optimization used in SCA. We show the capabilities of both BOHB and ge+ ntge on four different public datasets. Specifically, BOHB could obtain the least number of traces in the dataset called CTF2018 when trained in the Hamming weight and identity leakage models. Notably, this marks the first reported successful recovery of the key for the identity leakage model in CTF2018.

## 题录证据（核验日：2026-10-27）

- 用户WoS导出记录 W230，UT=WOS:001529722900012
- Crossref正式DOI元数据：https://api.crossref.org/works/10.1007/978-3-031-82841-6_12

Crossref日期字段：`{"published": {"date-parts": [[2025]]}, "published-print": {"date-parts": [[2025]]}, "published-online": {"date-parts": [[2025, 3, 13]]}}`。年份显示以本页“年份说明”区分会议届次、在线年和卷年。
