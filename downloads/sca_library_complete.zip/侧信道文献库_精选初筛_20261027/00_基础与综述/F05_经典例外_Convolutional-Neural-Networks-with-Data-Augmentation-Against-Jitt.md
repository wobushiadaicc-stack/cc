# F05｜Convolutional Neural Networks with Data Augmentation Against Jitter-Based Countermeasures

- **来源**：Lecture Notes in Computer Science / Cryptographic Hardware and Embedded Systems – CHES 2017。
- **年份说明**：CHES 2017；完整副标题以正式PDF为准。
- **作者**：Eleonora Cagli; Cécile Dumas; Emmanuel Prouff。
- **正式入口**：[10.1007/978-3-319-66787-4_3](https://doi.org/10.1007/978-3-319-66787-4_3)。
- **收录状态**：基础阅读单列；不占近三年高等级核心名额。
- **阅读优先级 / 难度**：P1 / 中。
- **内容判断依据**：仅题录/既有说明；需补摘要或全文复筛。
- **全文状态**：全文待补。

## 为什么放在这里

CNN与数据增强处理抖动，是理解错位问题的基础。

## 阅读时要回答的问题

增强模拟的扰动是否对应真实反制措施？什么信息可能被增强破坏？

## 前置知识

按优先阅读路线推进；已有知识可快速复习。

## 内容核验缺口

本轮未取得可核验的完整摘要/正文；中文定位只用于规划阅读，不能作为已证实的方法细节或实验结论。

## 题录证据（核验日：2026-10-27）

- Crossref正式DOI元数据：https://api.crossref.org/works/10.1007/978-3-319-66787-4_3

Crossref日期字段：`{"published": {"date-parts": [[2017]]}, "published-print": {"date-parts": [[2017]]}, "published-online": {"date-parts": [[2017, 8, 25]]}}`。年份显示以本页“年份说明”区分会议届次、在线年和卷年。
