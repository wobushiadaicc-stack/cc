# B04｜CL-SCA: A Contrastive Learning Approach for Profiled Side-Channel Analysis

- **来源**：IEEE Transactions on Information Forensics and Security。
- **年份说明**：TIFS 2025；本轮仅核题录。
- **作者**：Annyu Liu; An Wang; Shaofei Sun; Congming Wei; Yaoling Ding; Yongjuan Wang; Liehuang Zhu。
- **正式入口**：[10.1109/tifs.2025.3570123](https://doi.org/10.1109/tifs.2025.3570123)。
- **收录状态**：按所提供表暂符合一区/二区，待确认口径。
- **阅读优先级 / 难度**：P2 / 中高。
- **内容判断依据**：仅题录/既有说明；需补摘要或全文复筛。
- **全文状态**：全文待补。

## 为什么放在这里

对比学习侧信道分析；正式题录已核，详细方法需要补摘要或全文后确认。

## 阅读时要回答的问题

正负样本怎样构造？是否使用目标攻击迹或标签，使用发生在哪个阶段？

## 前置知识

训练/验证/攻击数据划分、交叉熵和GE；优化/对比学习条目建议先补相应基础。

## 内容核验缺口

本轮未取得可核验的完整摘要/正文；中文定位只用于规划阅读，不能作为已证实的方法细节或实验结论。

## 题录证据（核验日：2026-10-27）

- Crossref正式DOI元数据：https://api.crossref.org/works/10.1109/tifs.2025.3570123

Crossref日期字段：`{"published": {"date-parts": [[2025]]}, "published-print": {"date-parts": [[2025]]}}`。年份显示以本页“年份说明”区分会议届次、在线年和卷年。

## 2025分区表匹配补充（2026-10-29）

用户提供2025表，第8593行；原表未注明大类/小类，未独立核实官方来源；表中分区：1区。此结果不是官方大类分区核实结论。
