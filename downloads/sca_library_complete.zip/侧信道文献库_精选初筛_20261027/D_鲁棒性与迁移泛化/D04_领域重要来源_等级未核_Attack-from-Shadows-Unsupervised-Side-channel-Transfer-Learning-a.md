# D04｜Attack from Shadows: Unsupervised Side-channel Transfer Learning across Devices and Modalities

- **来源**：Proceedings of the ACM Asia Conference on Computer and Communications Security。
- **年份说明**：ASIACCS 2026。
- **作者**：Saion Kumar Roy; Ziyue Zhang; A. Adam Ding; Yunsi Fei。
- **正式入口**：[10.1145/3779208.3805969](https://doi.org/10.1145/3779208.3805969)。
- **收录状态**：按领域重要来源路线保留；正式发表已核，未声称中科院分区或本轮已核CCF级别。
- **阅读优先级 / 难度**：P2 / 中高。
- **内容判断依据**：摘要初筛；未逐节精读或复现实验。
- **全文状态**：全文待补。

## 为什么放在这里

UTLA：使用目标无标签迹训练独立编码器，拓展设备和模态差异。

## 阅读时要回答的问题

无监督适应是否使用全部目标攻击迹？应如何区分零样本泛化与目标域适应？

## 前置知识

建模攻击与源域/目标域；先区分跨设备、跨采集、跨算法实现和人工扰动。

## 原文摘要（供检索与初筛）

In this work, we focus on unsupervised transfer learning attacks in side-channel analysis, where a passive adversary leverages only unlabeled traces from a target device to recover its secret key. This setting reflects a realistic assumption in practical scenarios where collecting labeled traces from the target device is infeasible, particularly for proprietary devices or cloud computing environments. Prior unsupervised deep learning side-channel analysis (DL-SCA) methods assume that a single domain-invariant model suffices across both source and target domains, but this assumption breaks down as device discrepancy increases, such as across different hardware platforms, side-channel modalities, or implementations. We address this gap with the Unsupervised Transfer Learning Attack (UTLA), which uses a separate encoder with a shared classifier to yield lower DL-SCA loss and improved key extraction fidelity. UTLA keeps the source classifier fixed while training a target-specific encoder, using Maximum Mean Discrepancy (MMD) regularization to align feature distributions. Unlike prior approaches that fail under significant domain mismatch, UTLA enables reliable key recovery across diverse scenarios: (a) different hardware platforms, from a Spartan-6 FPGA to an XMEGA MCU using only 61 traces; ( b) different leakage modalities, from power measurements on an XMEGA MCU to cache-timing traces on an x86 processor using 435 traces; and (c) different implementations, from masked and shuffled AES on STM32 (ASCADv2) to masked AES on AVR (ASCADv1) using 1519 traces. Our results reveal a significant security implication: public side-channel datasets can serve as effective attack vectors against unseen devices implementing the same cryptographic algorithm.

## 题录证据（核验日：2026-10-27）

- 用户WoS导出记录 W190，UT=WOS:001866420300026
- Crossref正式DOI元数据：https://api.crossref.org/works/10.1145/3779208.3805969

Crossref日期字段：`{"published": {"date-parts": [[2026, 6]]}, "published-print": {"date-parts": [[2026, 6]]}, "published-online": {"date-parts": [[2026, 6, 4]]}}`。年份显示以本页“年份说明”区分会议届次、在线年和卷年。
