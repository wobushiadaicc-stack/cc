# F04｜Deep learning for side-channel analysis and introduction to ASCAD database

- **来源**：Journal of Cryptographic Engineering。
- **年份说明**：JCE正式卷年2020；在线2019；原始报告2018。
- **作者**：Ryad Benadjila; Emmanuel Prouff; Rémi Strullu; Eleonora Cagli; Cécile Dumas。
- **正式入口**：[10.1007/s13389-019-00220-8](https://doi.org/10.1007/s13389-019-00220-8)。
- **收录状态**：基础阅读单列；不占近三年高等级核心名额。
- **阅读优先级 / 难度**：P1 / 入门。
- **内容判断依据**：仅题录/既有说明；需补摘要或全文复筛。
- **全文状态**：全文待补。

## 为什么放在这里

ASCAD基础：弄清数据、标签、掩码和评估脚本。

## 阅读时要回答的问题

固定密钥/变化密钥版本如何区分？训练、验证、攻击集怎样隔离？

## 前置知识

按优先阅读路线推进；已有知识可快速复习。

## 作者代码 / 数据入口

https://github.com/ANSSI-FR/ASCAD

入口来自论文、官方摘要或既有作者项目；不代表已运行代码或下载数据。

## 内容核验缺口

本轮未取得可核验的完整摘要/正文；中文定位只用于规划阅读，不能作为已证实的方法细节或实验结论。

## 题录证据（核验日：2026-10-27）

- Crossref正式DOI元数据：https://api.crossref.org/works/10.1007/s13389-019-00220-8

Crossref日期字段：`{"published": {"date-parts": [[2019, 11, 30]]}, "published-print": {"date-parts": [[2020, 6]]}, "published-online": {"date-parts": [[2019, 11, 30]]}}`。年份显示以本页“年份说明”区分会议届次、在线年和卷年。
