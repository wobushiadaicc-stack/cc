# A10｜HypSCA: A Hyperbolic Embedding Method for Enhanced Side-Channel Attack

- **来源**：IEEE Transactions on Information Forensics and Security。
- **年份说明**：2026；精确首次在线日期待出版社确认。
- **作者**：Kaibin Li; Yihuai Liang; Zhengchun Zhou; Shui Yu。
- **正式入口**：[10.1109/tifs.2026.3734751](https://doi.org/10.1109/tifs.2026.3734751)。
- **收录状态**：按所提供表暂符合一区/二区，待确认口径。
- **阅读优先级 / 难度**：P3 / 高。
- **内容判断依据**：摘要初筛；未逐节精读或复现实验。
- **全文状态**：全文待补。

## 为什么放在这里

HypSCA：双曲空间与欧氏空间的联合表示，作为表示学习拓展。

## 阅读时要回答的问题

泄漏的层次结构怎样被测量？收益是否超过增加的优化和调参成本？

## 前置知识

CPA、ASCAD标签与GE；CNN基本结构。解释性和双曲表示另需对应数学基础。

## 原文摘要（供检索与初筛）

Deep learning-based side-channel attack (DLSCA) has become the dominant paradigm for extracting sensitive information from hardware implementations due to its ability to learn discriminative features directly from raw side-channel traces. A common design choice in DLSCA involves embedding traces in Euclidean space, where the underlying geometry supports conventional objectives such as classification or contrastive learning. However, Euclidean space is fundamentally limited in capturing the multi-level hierarchical structure of side-channel traces, which often exhibit both coarse-grained clustering patterns (e.g., Hamming weight similarities) and fine-grained distinctions (e.g., instruction-level variations). These limitations adversely affect the discriminability of learned representations, particularly across diverse datasets and leakage models. In this work, we propose HypSCA, a dual-space representation learning method that embeds traces in hyperbolic space to exploit its natural ability to model hierarchical relationships through exponential volume growth. In contrast to existing approaches, HypSCA jointly combines hyperbolic structure modeling with local discriminative learning in Euclidean space, enabling the preservation of global hierarchies while enhancing fine-grained feature separation. Quantitative geometric analysis shows measurable hierarchical organization, most clearly under the HW model. Consequently, extensive experiments demonstrate that HypSCA achieves superior attack performance, outperforming SOTA methods by up to 30.8%.

## 题录证据（核验日：2026-10-27）

- 用户WoS导出记录 W143，UT=WOS:001885970500009
- Crossref正式DOI元数据：https://api.crossref.org/works/10.1109/tifs.2026.3734751

Crossref日期字段：`{"published": {"date-parts": [[2026]]}, "published-print": {"date-parts": [[2026]]}}`。年份显示以本页“年份说明”区分会议届次、在线年和卷年。

## 2025分区表匹配补充（2026-10-29）

用户提供2025表，第8593行；原表未注明大类/小类，未独立核实官方来源；表中分区：1区。此结果不是官方大类分区核实结论。
