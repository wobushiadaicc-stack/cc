# D10｜Enhancing Scale and Shift Invariance in Deep Learning-Based Side-Channel Attacks Through Equivariant Convolutional Neural Networks

- **来源**：Lecture Notes in Computer Science / Topics in Cryptology – CT-RSAC 2026。
- **年份说明**：CT-RSAC 2026；本轮仅核题录，重点机制待全文核查。
- **作者**：David Perez; Sengim Karayalcin; Stjepan Picek; Servio Paguada。
- **正式入口**：[10.1007/978-3-032-22931-1_8](https://doi.org/10.1007/978-3-032-22931-1_8)。
- **收录状态**：按领域重要来源路线保留；正式发表已核，未声称中科院分区或本轮已核CCF级别。
- **阅读优先级 / 难度**：P2 / 中高。
- **内容判断依据**：仅题录/既有说明；需补摘要或全文复筛。
- **全文状态**：全文待补。

## 为什么放在这里

等变CNN用于尺度与平移变化，作为Transformer鲁棒性的结构对照。

## 阅读时要回答的问题

等变与不变怎样区别？是否验证真实时钟变化而不只是人工缩放？

## 前置知识

建模攻击与源域/目标域；先区分跨设备、跨采集、跨算法实现和人工扰动。

## 内容核验缺口

本轮未取得可核验的完整摘要/正文；中文定位只用于规划阅读，不能作为已证实的方法细节或实验结论。

## 题录证据（核验日：2026-10-27）

- Crossref正式DOI元数据：https://api.crossref.org/works/10.1007/978-3-032-22931-1_8

Crossref日期字段：`{"published": {"date-parts": [[2026]]}, "published-print": {"date-parts": [[2026]]}, "published-online": {"date-parts": [[2026, 7, 2]]}}`。年份显示以本页“年份说明”区分会议届次、在线年和卷年。
