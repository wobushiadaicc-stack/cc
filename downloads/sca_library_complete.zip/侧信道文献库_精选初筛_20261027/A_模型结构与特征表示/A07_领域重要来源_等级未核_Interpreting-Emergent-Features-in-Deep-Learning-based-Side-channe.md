# A07｜Interpreting Emergent Features in Deep Learning-based Side-channel Analysis

- **来源**：NeurIPS 2025。
- **年份说明**：NeurIPS 2025；官网引用元数据显示2026-04-23，会议年与页面日期分别记录。
- **作者**：Karayalcin, Sengim; Krček, Marina; Picek, Stjepan。
- **正式入口**：[10.52202/085713-3155](https://doi.org/10.52202/085713-3155)。
- **收录状态**：按领域重要来源路线保留；正式发表已核，未声称中科院分区或本轮已核CCF级别。
- **阅读优先级 / 难度**：P2 / 高。
- **内容判断依据**：摘要初筛；未逐节精读或复现实验。
- **全文状态**：附英文全文（已验证可解析）。

## 为什么放在这里

通过机理可解释性研究模型如何组合泄漏、恢复掩码。

## 阅读时要回答的问题

如何验证发现的特征确实对应秘密掩码？与普通注意力热图有什么区别？

## 前置知识

CPA、ASCAD标签与GE；CNN基本结构。解释性和双曲表示另需对应数学基础。

## 本地全文

[A07_领域重要来源_等级未核_Interpreting-Emergent-Features-in-Deep-Learning-based-Side-channe.pdf](A07_领域重要来源_等级未核_Interpreting-Emergent-Features-in-Deep-Learning-based-Side-channe.pdf)（30 页）。

## 原文摘要（供检索与初筛）

Side-channel analysis (SCA) poses a real-world threat by exploiting unintentional physical signals to extract secret information from secure devices. Evaluation labs also use the same techniques to certify device security. In recent years, deep learning has emerged as a prominent method for SCA, achieving state-of-the-art attack performance at the cost of interpretability. Understanding how neural networks extract secrets is crucial for security evaluators aiming to defend against such attacks, as only by understanding the attack can one propose better countermeasures.  In this work, we apply mechanistic interpretability to neural networks trained for SCA, revealing $\textit{how}$ models exploit $\textit{what}$ leakage in side-channel traces. We focus on sudden jumps in performance to reverse engineer learned representations, ultimately recovering secret masks and moving the evaluation process from black-box to white-box. Our results show that mechanistic interpretability can scale to realistic SCA settings, even when relevant inputs are sparse, model accuracies are low, and side-channel protections prevent standard input interventions.

## 题录证据（核验日：2026-10-27）

- 出版方页面：https://papers.nips.cc/paper_files/paper/2025/hash/878147474808c35add04cf4852d2c996-Abstract-Conference.html
