# D05｜Cross-Attention for AES Mode Variation in Side-Channel Analysis

- **来源**：2025 62nd ACM/IEEE Design Automation Conference (DAC)。
- **年份说明**：DAC 2025；会议等级本轮未逐项核验。
- **作者**：Fanliang Hu; Jian Shen; Haoyu Ma; Qingming Jonathan Wu。
- **正式入口**：[10.1109/dac63849.2025.11132714](https://doi.org/10.1109/dac63849.2025.11132714)。
- **收录状态**：按领域重要来源路线保留；正式发表已核，未声称中科院分区或本轮已核CCF级别。
- **阅读优先级 / 难度**：P2 / 中。
- **内容判断依据**：摘要初筛；未逐节精读或复现实验。
- **全文状态**：全文待补。

## 为什么放在这里

Cross-attention与无监督域适应处理AES工作模式变化。

## 阅读时要回答的问题

跨模式变化与跨设备变化有什么不同？对齐时需要哪些目标信息？

## 前置知识

建模攻击与源域/目标域；先区分跨设备、跨采集、跨算法实现和人工扰动。

## 原文摘要（供检索与初筛）

Portability poses a significant challenge for Deep Learning (DL)-based profiling Side-Channel Analysis (SCA) on AES encryption, as attackers cannot always ensure that training and target samples use the same encryption mode. To address this, we propose an Unsupervised Domain Adaptation (UDA) DL-SCA framework for achieving effective and robust cross-encryption-mode attacks. By incorporating cross-attention and UDA techniques, our framework aligns high-dimensional input samples, reducing interference from encryption mode mismatches. Evaluation across five distinct AES modes demonstrates that our method achieves robust SCA performance without requiring prior knowledge or multiple labeled datasets for analysis.

## 题录证据（核验日：2026-10-27）

- 用户WoS导出记录 W127，UT=WOS:001672958600141
- Crossref正式DOI元数据：https://api.crossref.org/works/10.1109/dac63849.2025.11132714

Crossref日期字段：`{"published": {"date-parts": [[2025, 6, 22]]}, "published-print": {"date-parts": [[2025, 6, 22]]}}`。年份显示以本页“年份说明”区分会议届次、在线年和卷年。
