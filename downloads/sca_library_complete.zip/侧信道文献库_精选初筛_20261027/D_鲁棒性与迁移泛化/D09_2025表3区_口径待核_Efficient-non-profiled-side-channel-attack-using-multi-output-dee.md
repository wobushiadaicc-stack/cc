# D09｜Efficient non-profiled side-channel attack using multi-output deep neural network and transfer learning

- **来源**：Computer Networks。
- **年份说明**：2026；并非当然属于零标签跨设备泛化。
- **作者**：Huy-Thanh Le; Ngoc-Tuan Do; Van-Phuc Hoang; Huu Minh Nguyen。
- **正式入口**：[10.1016/j.comnet.2026.112689](https://doi.org/10.1016/j.comnet.2026.112689)。
- **收录状态**：按所提供表为三区，不满足一区/二区路线；CCF等价路线另核。
- **阅读优先级 / 难度**：P3 / 中高。
- **内容判断依据**：摘要初筛；未逐节精读或复现实验。
- **全文状态**：全文待补。

## 为什么放在这里

多输出网络与迁移学习结合的非建模攻击；作为D类学习范式拓展。

## 阅读时要回答的问题

源任务与目标任务是什么？迁移学习是否真的证明跨设备有效，还是仅节省训练？

## 前置知识

建模攻击与源域/目标域；先区分跨设备、跨采集、跨算法实现和人工扰动。

## 原文摘要（供检索与初筛）

Side-Channel Analysis (SCA) is a powerful attack methodology that leverages physical information that was accidentally leaked by cryptographic devices, such as power consumption, electromagnetic emanations, execution time. In this research, we specifically focus on enhancing the effectiveness of non-profiled SCA against the AES-128 algorithm through the application of transfer learning techniques. Transfer learning offers a significant advantage by enabling the leveraging of knowledge from deep learning models pre-trained related datasets, thereby bolstering attack capabilities even when faced with limited available traces. We propose novel models that integrate transfer learning with Multi-Output Deep Learning Side-Channel Analysis (MO-DLSCA) architectures to improve the overall efficiency of the non-profiled SCA. Experimental validations were rigorously conducted on both the ASCAD dataset and a dataset collected from a ChipWhisperer board, allowing for a direct performance comparison between the original MO-DLSCA models and their transfer learning-enhanced counterparts. The results conclusively demonstrate that the proposed models not only maintain a high accuracy, consistently achieving over 80% success in key recovery, but also significantly reduce both the attack time by up to 24.7% and the required number of power traces from 30% to 60% depending the specific countermeasure scenario and model architecture. This promising outcome highlights a substantial potential for this approach within the field of the non-profiled side-channel analysis.

## 题录证据（核验日：2026-10-27）

- 用户WoS导出记录 W084，UT=WOS:001887753100001
- Crossref正式DOI元数据：https://api.crossref.org/works/10.1016/j.comnet.2026.112689

Crossref日期字段：`{"published": {"date-parts": [[2026, 11]]}, "published-print": {"date-parts": [[2026, 11]]}}`。年份显示以本页“年份说明”区分会议届次、在线年和卷年。

## 2025分区表匹配补充（2026-10-29）

用户提供2025表，第4483行；原表未注明大类/小类，未独立核实官方来源；表中分区：3区。此结果不是官方大类分区核实结论。
