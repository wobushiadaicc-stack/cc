# D07｜Unleashing Cross-Domain Potential: Side-Channel Analysis with Autoencoder for Domain Adaptation

- **来源**：ACM Transactions on Embedded Computing Systems。
- **年份说明**：2026。
- **作者**：Xiaoyu Du; Haowen Tan; Jian Shen; Pandi Vijayakumar; Sangman Moh; Q. M. Jonathan Wu。
- **正式入口**：[10.1145/3800949](https://doi.org/10.1145/3800949)。
- **收录状态**：按所提供表为三区，不满足一区/二区路线；CCF等价路线另核。
- **阅读优先级 / 难度**：P2 / 中。
- **内容判断依据**：摘要初筛；未逐节精读或复现实验。
- **全文状态**：全文待补。

## 为什么放在这里

以自编码器潜空间和MMD做跨设备分布对齐。

## 阅读时要回答的问题

重构目标和分类目标是否冲突？多源域是否增加额外设备访问要求？

## 前置知识

建模攻击与源域/目标域；先区分跨设备、跨采集、跨算法实现和人工扰动。

## 原文摘要（供检索与初筛）

Deep learning based side-channel analysis (DL-SCA) has achieved remarkable success in recovering cryptographic keys from embedded devices by exploiting physical leakages such as power consumption and electromagnetic emissions, posing a serious threat to the security of cryptographic implementations. However, a major challenge arises in cross-device attacks, where a model trained on profiling devices cannot be directly applied to attack a different device. This is because domain discrepancies emerge from variations in chip architecture, manufacturing, operational conditions, and data acquisition methods between these two devices. Many existing DL-SCA schemes have not adequately addressed the challenges posed by the differences. Therefore, we propose a novel cross-device SCA framework based on an autoencoder, which leverages the encoder-decoder architecture to align feature distributions across devices in the latent space while simultaneously preserving discriminative leakage features through the reconstruction process. To achieve this, Maximum Mean Discrepancy (MMD) is integrated into the loss function and applied to the latent representations, effectively narrowing the distribution gap between profiling and attack devices. Operating in the latent space allows our approach to avoid the training instability of adversarial methods and provides an efficient end-to-end solution for domain alignment. Building on this framework, we further introduce three multi-domain adaptation methods. Experimental results, evaluated in terms of Partial Guessing Entropy (PGE), demonstrate that cross-device attacks can be effectively executed even with device discrepancies, with most keys being successfully recovered within 1,000 traces. Moreover, the proposed adaptation techniques significantly reduce the number of traces required for successful key recovery.

## 题录证据（核验日：2026-10-27）

- 用户WoS导出记录 W358，UT=WOS:001854733500001
- Crossref正式DOI元数据：https://api.crossref.org/works/10.1145/3800949

Crossref日期字段：`{"published": {"date-parts": [[2026, 4, 14]]}, "published-print": {"date-parts": [[2026, 5, 31]]}, "published-online": {"date-parts": [[2026, 4, 14]]}}`。年份显示以本页“年份说明”区分会议届次、在线年和卷年。

## 2025分区表匹配补充（2026-10-29）

用户提供2025表，第103行；原表未注明大类/小类，未独立核实官方来源；表中分区：3区。此结果不是官方大类分区核实结论。
