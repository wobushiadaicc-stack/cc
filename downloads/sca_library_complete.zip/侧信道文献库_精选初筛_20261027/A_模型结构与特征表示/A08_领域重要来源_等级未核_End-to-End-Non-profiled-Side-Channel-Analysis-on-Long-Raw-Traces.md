# A08｜End-to-End Non-profiled Side-Channel Analysis on Long Raw Traces

- **来源**：Lecture Notes in Computer Science / Computer Security – ESORICS 2025。
- **年份说明**：ESORICS 2025；在线2025，章节卷年2026。
- **作者**：Jintong Yu; Yuxuan Wang; Shipei Qu; Yubo Zhao; Yipeng Shi; Pei Cao; Xiangjun Lu; Chi Zhang; Dawu Gu; Cheng Hong。
- **正式入口**：[10.1007/978-3-032-07894-0_27](https://doi.org/10.1007/978-3-032-07894-0_27)。
- **收录状态**：按领域重要来源路线保留；正式发表已核，未声称中科院分区或本轮已核CCF级别。
- **阅读优先级 / 难度**：P2 / 中高。
- **内容判断依据**：摘要初筛；未逐节精读或复现实验。
- **全文状态**：全文待补。

## 为什么放在这里

端到端非建模攻击长原始迹，用于比较人工选点与直接分析。

## 阅读时要回答的问题

不使用建模标签时如何训练？长迹实验的攻击者假设与成本是什么？

## 前置知识

CPA、ASCAD标签与GE；CNN基本结构。解释性和双曲表示另需对应数学基础。

## 原文摘要（供检索与初筛）

With the advancement of deep learning techniques, Deep Learning-based Non-profiled Side-Channel Analysis (DL-NSCA) can automatically learn and combine features, making it a promising method that can skip the manual and precise selection of Points of Interest (PoIs). Existing DL-NSCA methods assume that the attacker can identify a short leakage interval (usually less than 5000 points) containing PoIs from raw traces (more than 100,000 points) and then feed the leakage interval into the neural network to recover the key. However, in practice, the attacker often faces a black-box scenario with unknown underlying implementations, making locating the short interval from raw traces challenging, especially when masking countermeasures exist. To address this issue, we propose a lightweight end-to-end DL-NSCA model called convWIN-MCR, which consists of a performance-optimizing component, convWIN, and an accelerator component, MCR. It can efficiently process raw traces without the need to manually identify the short leakage interval. On the public dataset ASCADv1, while the state-of-the-art model Multi-Output Regression (MOR) requires 28,000 traces and 24 min to recover the key from the leakage interval with 1,400 feature points, our framework only requires 6,000 traces in 13 min to directly analyze raw traces with 250,000 feature points. To further validate the practical applicability of our framework, we successfully crack a commercial USIM card by analyzing its raw traces and recovering its 128-bit AES key.

## 题录证据（核验日：2026-10-27）

- 用户WoS导出记录 W060，UT=WOS:001656843900027
- Crossref正式DOI元数据：https://api.crossref.org/works/10.1007/978-3-032-07894-0_27

Crossref日期字段：`{"published": {"date-parts": [[2025, 10, 18]]}, "published-print": {"date-parts": [[2026]]}, "published-online": {"date-parts": [[2025, 10, 18]]}}`。年份显示以本页“年份说明”区分会议届次、在线年和卷年。
