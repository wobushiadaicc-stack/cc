# D03｜Enhancing Model Generalization for Efficient Cross-Device Side-Channel Analysis

- **来源**：IEEE Transactions on Information Forensics and Security。
- **年份说明**：2025。
- **作者**：Yimeng Chen; Bo Wang; Changshan Su; Ao Li; Yuxing Tang; Gen Li。
- **正式入口**：[10.1109/tifs.2025.3611696](https://doi.org/10.1109/tifs.2025.3611696)。
- **收录状态**：按所提供表暂符合一区/二区，待确认口径。
- **阅读优先级 / 难度**：P2 / 中高。
- **内容判断依据**：摘要初筛；未逐节精读或复现实验。
- **全文状态**：全文待补。

## 为什么放在这里

DDPM与自适应多任务损失用于跨设备泛化。

## 阅读时要回答的问题

生成模型和多任务损失各自改善了什么？五个跨设备任务如何划分？

## 前置知识

建模攻击与源域/目标域；先区分跨设备、跨采集、跨算法实现和人工扰动。

## 原文摘要（供检索与初筛）

Deep learning (DL)-based techniques have garnered significant attention as an innovative method for profiled side-channel analysis (SCA). Despite their proven effectiveness, recent studies have highlighted challenges faced by DL-based profiled attacks in a more realistic portability threat model, where two devices are used respectively for profiling and the attack. In this paper, we propose a novel approach for cross-device attack by incorporating the Denoising Diffusion Probabilistic Model (DDPM) to develop a generalized model. Additionally, an adaptive multi-task loss is employed to balance multiple training objectives that respectively focus on model generalization and precision. We evaluate our strategy on five cross-device SCA datasets. The experimental results show that, compared to baseline methods, our approach achieves significantly enhanced performance, as measured by the number of traces required to recover the secret key. Specifically, on a more challenging dataset obtained from three SAKURA-G evaluation boards, our method successfully recovers the secret key using approximately 300 traces, whereas baseline methods fail to guarantee a successful cross-device attack even with 5,000 traces. Furthermore, our method demonstrates remarkably enhanced attack efficiency, reducing attack time by over an hour compared to the baselines.

## 题录证据（核验日：2026-10-27）

- 用户WoS导出记录 W185，UT=WOS:001586179900001
- Crossref正式DOI元数据：https://api.crossref.org/works/10.1109/tifs.2025.3611696

Crossref日期字段：`{"published": {"date-parts": [[2025]]}, "published-print": {"date-parts": [[2025]]}}`。年份显示以本页“年份说明”区分会议届次、在线年和卷年。

## 2025分区表匹配补充（2026-10-29）

用户提供2025表，第8593行；原表未注明大类/小类，未独立核实官方来源；表中分区：1区。此结果不是官方大类分区核实结论。
