# C02｜An Effective Tool for Traces Preprocessing in Side-Channel Analysis: Ridge Energies Extraction From Synchrosqueezing Wavelet Transform

- **来源**：IEEE Internet of Things Journal。
- **年份说明**：2025。
- **作者**：Yuanzhen Wang; Hongxin Zhang; Shaofei Sun; Yunfei Ma; Xiaofeng Wei; Zhi Sun; Md Sabbir Hosen。
- **正式入口**：[10.1109/jiot.2025.3572953](https://doi.org/10.1109/jiot.2025.3572953)。
- **收录状态**：按所提供表暂符合一区/二区，待确认口径。
- **阅读优先级 / 难度**：P1 / 中。
- **内容判断依据**：摘要初筛；未逐节精读或复现实验。
- **全文状态**：全文待补。

## 为什么放在这里

同步压缩小波变换与脊线能量提取，补充不依赖训练的预处理基线。

## 阅读时要回答的问题

预处理参数是否依赖真实密钥？和普通小波、对齐方法如何公平比较？

## 前置知识

采样迹、SNR、GE和基本信号处理；先理解参考迹与攻击者能力。

## 原文摘要（供检索与初筛）

In recent years, deep learning methods have become prevalent in the field of side-channel analysis (SCA), leading to a decline in research on nonprofiled attacks and their preprocessing techniques. However, while deep-learning-based SCA methods can reduce the requirements for the quality of leakage signals, they do not fully resolve the need for preprocessing in SCA. Additionally, there is a lack of universal, nontrained preprocessing methods for side-channel leakage under various types of interference. In this article, a new method for preprocessing side channel leakage using synchrosqueezing wavelet transform and ridge energy extraction is proposed to deal with complex scenarios. This method involves two steps: first, applying synchrosqueezing theory to concentrate signal energy in the wavelet domain, and second, utilizing a dynamic path optimization algorithm to locate and extract ridge energy for subsequent attacks. Our proposed solution extracts key information features from the traces, effectively addressing trace distortion caused by varying levels of noise and random disturbances. We validate the effectiveness of our analysis and solution through extensive experiments on four public databases and two self-collected datasets containing power and electromagnetic leakage (EM) from both hardware and software encryption implementations. We compare our experimental results from four indicators: 1) success rate; 2) guessing entropy; 3) signal to noise ratio; and 4) normalized interclass varianc. Besides, we demonstrate the advantages of our method by comparing Measurements to Disclosure and on public datasets. Our method demonstrates significant potential for preprocessing traces in nonprofiled SCA.

## 题录证据（核验日：2026-10-27）

- 用户WoS导出记录 W121，UT=WOS:001552192600002
- Crossref正式DOI元数据：https://api.crossref.org/works/10.1109/jiot.2025.3572953

Crossref日期字段：`{"published": {"date-parts": [[2025, 8, 15]]}, "published-print": {"date-parts": [[2025, 8, 15]]}}`。年份显示以本页“年份说明”区分会议届次、在线年和卷年。

## 2025分区表匹配补充（2026-10-29）

用户提供2025表，第8484行；原表未注明大类/小类，未独立核实官方来源；表中分区：2区。此结果不是官方大类分区核实结论。
