# E07｜Uncertainty Estimation in Neural Network-enabled Side-channel Analysis and Links to Explainability

- **来源**：IACR Transactions on Cryptographic Hardware and Embedded Systems。
- **年份说明**：TCHES 2026。
- **作者**：Seyedmohammad Nouraniboosjin; Fatemeh Ganji。
- **正式入口**：[10.46586/tches.v2026.i2.764-807](https://doi.org/10.46586/tches.v2026.i2.764-807)。
- **收录状态**：按领域重要来源路线保留；正式发表已核，未声称中科院分区或本轮已核CCF级别。
- **阅读优先级 / 难度**：P2 / 高。
- **内容判断依据**：摘要初筛；未逐节精读或复现实验。
- **全文状态**：附英文全文（已验证可解析）。

## 为什么放在这里

用Rényi信息量区分模型不确定性和数据不确定性，并关联解释方法。

## 阅读时要回答的问题

错误高置信预测来自模型还是数据？不确定性与key rank的关系是否稳定？

## 前置知识

CPA/ASCAD与统计指标；信息论条目需熵、互信息和统计估计基础。

## 本地全文

[E07_领域重要来源_等级未核_Uncertainty-Estimation-in-Neural-Network-enabled-Side-channel-Ana.pdf](E07_领域重要来源_等级未核_Uncertainty-Estimation-in-Neural-Network-enabled-Side-channel-Ana.pdf)（44 页）。

## 原文摘要（供检索与初筛）

Side-channel analysis (SCA) has emerged as a critical field in securing hardware implementations against potential vulnerabilities. With the advent of artificial intelligence (AI), neural network-based approaches have proven to be among the most useful techniques for profiled SCA. Despite the success of NN-assisted SCA, a critical challenge remains, namely understanding how confident NNs are in their predictions. NNs often exhibit uncertainty in their predictions, leading to incorrect key guesses with high probabilities, corresponding to a higher rank associated with the correct key. This uncertainty stems from multiple factors, including measurement errors, randomness in physical quantities, and variability in NN training. Understanding whether this uncertainty arises from inherent data characteristics or can be mitigated through better training is crucial. Additionally, if data uncertainty dominates, identifying specific trace features responsible for misclassification becomes essential.
We propose a novel approach to estimating uncertainty in NN-based SCA by leveraging Rényi entropy, which offers a generalized framework for capturing various forms of uncertainty. This metric allows us to quantify uncertainty in NN predictions and explain its impact on key recovery. We decompose uncertainty into epistemic (modelrelated) and aleatoric (data-related) components. Given the challenge of estimating probability distributions in high-dimensional spaces, we use matrix-based Rényi α-entropy and α-divergence to better approximate leakage distributions, addressing the limitations of KL divergence in SCA. We also explore the sources of uncertainty, e.g., desynchronization, randomized keys, as well as hyperparameters related to NN training. To identify which time instances (features in traces) contribute most to uncertainty, we also integrate Shapley value-based explanations with our framework, overcoming the limitations of conventional sensitivity analysis. Lastly, we show that predictive uncertainty strongly correlates with standard SCA metrics like rank, offering a complementary measure for evaluating attack complexity. Our theoretical findings are backed by extensive experiments on available datasets and NN models.

## 题录证据（核验日：2026-10-27）

- 出版方页面：https://tches.iacr.org/index.php/TCHES/article/view/12908
