# F01｜A Review and Comparison of AI-enhanced Side Channel Analysis

- **来源**：ACM Journal on Emerging Technologies in Computing Systems。
- **年份说明**：JETC 2022；不是把2024的arXiv上传当首发；综述按基础用途保留。
- **作者**：Max Panoff; Honggang Yu; Haoqi Shan; Yier Jin。
- **正式入口**：[10.1145/3517810](https://doi.org/10.1145/3517810)。
- **收录状态**：基础阅读单列；不占近三年高等级核心名额。
- **阅读优先级 / 难度**：P1 / 入门。
- **内容判断依据**：摘要初筛；未逐节精读或复现实验。
- **全文状态**：全文待补。

## 为什么放在这里

建立建模/非建模攻击与AI方法的整体地图，属于背景综述。

## 阅读时要回答的问题

哪些攻击假设你已具备？哪些术语需要回到原始论文确认？

## 前置知识

按优先阅读路线推进；已有知识可快速复习。

## 原文摘要（供检索与初筛）

Side Channel Analysis (SCA) presents a clear threat to privacy and security in modern computing systems. The vast majority of communications are secured through cryptographic algorithms. These algorithms are often provably-secure from a cryptographical perspective, but their implementation on real hardware introduces vulnerabilities. Adversaries can exploit these vulnerabilities to conduct SCA and recover confidential information, such as secret keys or internal states. The threat of SCA has greatly increased as machine learning, and in particular deep learning, enhanced attacks become more common. In this work, we will examine the latest state-of-the-art deep learning techniques for side channel analysis, the theory behind them, and how they are conducted. Our focus will be on profiling attacks using deep learning techniques, but we will also examine some new and emerging methodologies enhanced by deep learning techniques, such as non-profiled attacks, artificial trace generation, and others. Finally, different deep learning–enhanced SCA schemes attempted against the ANSSI SCA Database and their relative performance will be evaluated and compared. This will lead to new research directions to secure cryptographic implementations against the latest SCA attacks.

## 题录证据（核验日：2026-10-27）

- Crossref正式DOI元数据：https://api.crossref.org/works/10.1145/3517810

Crossref日期字段：`{"published": {"date-parts": [[2022, 4, 28]]}, "published-print": {"date-parts": [[2022, 7, 31]]}, "published-online": {"date-parts": [[2022, 4, 28]]}}`。年份显示以本页“年份说明”区分会议届次、在线年和卷年。
