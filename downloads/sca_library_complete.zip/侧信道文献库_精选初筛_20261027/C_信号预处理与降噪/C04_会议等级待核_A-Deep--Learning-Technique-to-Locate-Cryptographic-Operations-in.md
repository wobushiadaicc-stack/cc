# C04｜A Deep- Learning Technique to Locate Cryptographic Operations in Side-Channel Traces

- **来源**：2024 Design, Automation & Test in Europe Conference & Exhibition (DATE)。
- **年份说明**：DATE 2024；主会论文，等级尚待目录核验。
- **作者**：Giuseppe Chiari; Davide Galli; Francesco Lattari; Matteo Matteucci; Davide Zoni。
- **正式入口**：[10.23919/date58400.2024.10546758](https://doi.org/10.23919/date58400.2024.10546758)。
- **收录状态**：方向候选；会议等级待核，不冒用其他会议等级。
- **阅读优先级 / 难度**：P1 / 中。
- **内容判断依据**：摘要初筛；未逐节精读或复现实验。
- **全文状态**：全文待补。

## 为什么放在这里

从长迹定位密码运算，再进行对齐与攻击，是实际流程的重要前置步骤。

## 阅读时要回答的问题

训练定位器需要哪些时间标注？定位误差如何影响密钥恢复？

## 前置知识

采样迹、SNR、GE和基本信号处理；先理解参考迹与攻击者能力。

## 原文摘要（供检索与初筛）

Side-channel attacks allow extracting secret information from the execution of cryptographic primitives by correlating the partially known computed data and the measured side-channel signal. However, to set up a successful side-channel attack, the attacker has to perform i) the challenging task of locating the time instant in which the target cryptographic primitive is executed inside a side-channel trace and then ii) the time-alignment of the measured data on that time instant. This paper presents a novel deep-learning technique to locate the time instant in which the target computed cryptographic operations are executed in the side-channel trace. In contrast to state-of-the-art solutions, the proposed methodology works even in the presence of trace deformations obtained through random delay insertion techniques. We validated our proposal through a successful attack against a variety of unprotected and protected cryptographic primitives that have been executed on an FPGA-implemented system-on-chip featuring a RISC-V CPU.

## 题录证据（核验日：2026-10-27）

- 用户WoS导出记录 W067，UT=WOS:001253778900244
- Crossref正式DOI元数据：https://api.crossref.org/works/10.23919/date58400.2024.10546758

Crossref日期字段：`{"published": {"date-parts": [[2024, 3, 25]]}, "published-print": {"date-parts": [[2024, 3, 25]]}}`。年份显示以本页“年份说明”区分会议届次、在线年和卷年。
