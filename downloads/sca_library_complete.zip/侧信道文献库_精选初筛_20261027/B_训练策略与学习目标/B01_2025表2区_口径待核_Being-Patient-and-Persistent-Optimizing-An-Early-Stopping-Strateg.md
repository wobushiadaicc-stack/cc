# B01｜Being Patient and Persistent: Optimizing An Early Stopping Strategy for Deep Learning in Profiled Attacks

- **来源**：IEEE Transactions on Computers。
- **年份说明**：正式卷年2025；DOI含2023，首次在线日期需另核。
- **作者**：Servio Paguada; Lejla Batina; Ileana Buhan; Igor Armendariz。
- **正式入口**：[10.1109/tc.2023.3234205](https://doi.org/10.1109/tc.2023.3234205)。
- **收录状态**：按所提供表暂符合一区/二区，待确认口径。
- **阅读优先级 / 难度**：P1 / 中。
- **内容判断依据**：摘要初筛；未逐节精读或复现实验。
- **全文状态**：全文待补。

## 为什么放在这里

以密钥恢复相关指标设计早停，适合先建立训练控制意识。

## 阅读时要回答的问题

早停使用哪部分数据？有没有把最终攻击集用于挑选模型？

## 前置知识

训练/验证/攻击数据划分、交叉熵和GE；优化/对比学习条目建议先补相应基础。

## 原文摘要（供检索与初筛）

The absence of an algorithm that effectively monitors the deep learning models used in side-channel attacks increases the difficulty of a security evaluation. If an attack is unsuccessful, that could be due to multiple reasons. It can be that we are indeed dealing with a resistant implementation, but it is possible that the deep learning model used is faulty. In this contribution, we formalize two conditions, persistence and patience, for a deep learning model to be optimal and we propose an early stopping algorithm that reliably recognizes the model's optimal state during training. The novelty of our solution is in an efficient implementation of guessing entropy estimation as a success metric used to measure the strength of a side-channel adversary. As a result, the model which uses our strategy for learning converges with fewer traces than other known methods.

## 题录证据（核验日：2026-10-27）

- 用户WoS导出记录 W026，UT=WOS:001420503200013
- Crossref正式DOI元数据：https://api.crossref.org/works/10.1109/tc.2023.3234205

Crossref日期字段：`{"published": {"date-parts": [[2025, 3, 1]]}, "published-print": {"date-parts": [[2025, 3, 1]]}}`。年份显示以本页“年份说明”区分会议届次、在线年和卷年。

## 2025分区表匹配补充（2026-10-29）

用户提供2025表，第8567行；原表未注明大类/小类，未独立核实官方来源；表中分区：2区。此结果不是官方大类分区核实结论。
