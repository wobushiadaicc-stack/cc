# A09｜Side-Channel Attacks on Protected Cryptographic Devices in Agentic AI: A Wavelet Scattering-Based Multi-Channel CNN Approach

- **来源**：IEEE Transactions on Cognitive Communications and Networking。
- **年份说明**：2026。
- **作者**：Xiaoyi Duan; Shenghan Zhu; Tong Jing; Ding Ding。
- **正式入口**：[10.1109/tccn.2025.3626384](https://doi.org/10.1109/tccn.2025.3626384)。
- **收录状态**：按所提供表暂符合一区/二区，待确认口径。
- **阅读优先级 / 难度**：P2 / 中。
- **内容判断依据**：摘要初筛；未逐节精读或复现实验。
- **全文状态**：全文待补。

## 为什么放在这里

小波散射与多通道CNN，直接连接课题组时频特征与多通道方法。

## 阅读时要回答的问题

散射变换的不变性是否会丢失关键泄漏？跨数据集实验是否分别重新训练？

## 前置知识

CPA、ASCAD标签与GE；CNN基本结构。解释性和双曲表示另需对应数学基础。

## 原文摘要（供检索与初筛）

The security of agentic artificial intelligence (AI) systems-such as autonomous vehicles and industrial robots-critically relies on the robustness of their cryptographic devices against physical attacks. Deep learning side-channel attacks (DLSCA) aim to recover cryptographic keys by analyzing the physical leakages of cryptographic devices using deep learning techniques. Presently, the effectiveness of most DLSCA schemes is significantly impacted by hiding countermeasures such as random delay. To address this challenge, we propose a novel architecture called the wavelet scattering-based multi-channel transmission convolutional neural network (SMT-CNN) for effective key recovery under random delay protection. In detail, the SMT-CNN consists of three key components: a wavelet scattering (WS) component, a multi-channel transmission (MCT) component and a convolutional neural network (CNN) component. The network leverages the translational invariance and small deformation stability of WS component to accomplish realignment of side-channel traces and feature extraction, where the underlying implementation is protected with random delay countermeasure. The MCT module enables multi-path feature transmission, while the CNN module performs final classification to recover key information. The generalizability of SMT-CNN is verified across several publicly available datasets, including the DPA contest v4, ASCAD_f and ASCAD_r datasets. Extensive comparison experiments show that SMT-CNN exhibits superior attack effectiveness compared to its counterparts in desynchronized scenarios.

## 题录证据（核验日：2026-10-27）

- 用户WoS导出记录 W033，UT=WOS:001651996900049
- Crossref正式DOI元数据：https://api.crossref.org/works/10.1109/tccn.2025.3626384

Crossref日期字段：`{"published": {"date-parts": [[2026]]}, "published-print": {"date-parts": [[2026]]}}`。年份显示以本页“年份说明”区分会议届次、在线年和卷年。

## 2025分区表匹配补充（2026-10-29）

用户提供2025表，第8561行；原表未注明大类/小类，未独立核实官方来源；表中分区：1区。此结果不是官方大类分区核实结论。
