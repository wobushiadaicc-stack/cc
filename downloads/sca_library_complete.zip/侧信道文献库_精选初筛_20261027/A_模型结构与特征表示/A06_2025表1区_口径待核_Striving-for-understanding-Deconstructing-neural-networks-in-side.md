# A06｜Striving for understanding: Deconstructing neural networks in side-channel analysis

- **来源**：Pattern Recognition。
- **年份说明**：2025。
- **作者**：Yimeng Chen; Bo Wang; Changshan Su; Ao Li; Gen Li; Yuxing Tang。
- **正式入口**：[10.1016/j.patcog.2025.111374](https://doi.org/10.1016/j.patcog.2025.111374)。
- **收录状态**：按所提供表暂符合一区/二区，待确认口径。
- **阅读优先级 / 难度**：P1 / 中。
- **内容判断依据**：摘要初筛；未逐节精读或复现实验。
- **全文状态**：全文待补。

## 为什么放在这里

用f-ANOVA与梯度可视化分析网络关键参数，帮助理解如何设计网络。

## 阅读时要回答的问题

关键超参数是否跨数据集稳定？可视化是相关证据还是足以支撑机理解释？

## 前置知识

CPA、ASCAD标签与GE；CNN基本结构。解释性和双曲表示另需对应数学基础。

## 原文摘要（供检索与初筛）

In recent years, neural network has garnered attention as an innovative method for profiling attack in Side- Channel Analysis (SCA). However, identifying effective networks for each crypto-system requires significant effort due to the black-box nature of neural networks and the diversity of side-channel signals. To address this challenge, we propose a methodology aimed at deconstructing neural networks formulated for SCA, with the goal of enhancing our understanding and facilitating the development of more effective profiling strategies. The proposed methodology commences with an innovative f-ANOVA-based method to identify pivotal network parameters amidst a plethora of adjustable parameters present in deep networks. Thereafter, a gradient-based network visualization technique is harnessed to graphically represent the effects of key parameter variations on network behaviors. Through the empirical experiments, we have successfully identified distinct crucial parameters that are then subjected to detailed analysis. Utilizing visualization analyses, we have distilled network formulation principles that are capable of accommodating the unique characteristics inherent in specific side-channel datasets. The experimental outcomes demonstrate that with network parameters accurately set based on the f-ANOVA evaluation results, the attack performance experiences a notable enhancement compared to the existing state-of-the-art techniques.

## 题录证据（核验日：2026-10-27）

- 用户WoS导出记录 W075，UT=WOS:001410502800001
- Crossref正式DOI元数据：https://api.crossref.org/works/10.1016/j.patcog.2025.111374

Crossref日期字段：`{"published": {"date-parts": [[2025, 6]]}, "published-print": {"date-parts": [[2025, 6]]}}`。年份显示以本页“年份说明”区分会议届次、在线年和卷年。

## 2025分区表匹配补充（2026-10-29）

用户提供2025表，第16797行；原表未注明大类/小类，未独立核实官方来源；表中分区：1区。此结果不是官方大类分区核实结论。
