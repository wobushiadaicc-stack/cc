# A_模型结构与特征表示

每篇只存入一个主目录。交叉主题通过文献卡中的定位与问题说明。P1是优先阅读，不是发表等级。

## 领域重要来源 / 基础单列

| 编号 | 论文 | 来源 | 优先级 | 全文 |
|---|---|---|---|---|
| A01 | [EstraNet: An Efficient Shift-Invariant Transformer Network for Side-Channel Analysis](A01.md) | IACR Transactions on Cryptographic Hardware and Embedded Systems | P1 | 有 |
| A05 | [Generalized Power Attacks against Crypto Hardware using Long-Range Deep Learning](A05.md) | IACR Transactions on Cryptographic Hardware and Embedded Systems | P2 | 有 |
| A07 | [Interpreting Emergent Features in Deep Learning-based Side-channel Analysis](A07.md) | NeurIPS 2025 | P2 | 有 |
| A08 | [End-to-End Non-profiled Side-Channel Analysis on Long Raw Traces](A08.md) | Lecture Notes in Computer Science / Computer Security – ESORICS 2025 | P2 | 待补 |

## 等级待核的方向候选

| 编号 | 论文 | 来源 | 优先级 | 全文 |
|---|---|---|---|---|
| A02 | [On the Instability of Softmax Attention-Based Deep Learning Models in Side-Channel Analysis](A02.md) | IEEE Transactions on Information Forensics and Security | P1 | 待补 |
| A03 | [TmsNet: An Efficient Transformer Network Based on Multiscale Shift-Invariance Mechanism for Side-Channel Analysis](A03.md) | IEEE Internet of Things Journal | P2 | 待补 |
| A04 | [Dual-Path Hybrid Residual Network for Profiled Side-Channel Analysis](A04.md) | IEEE Transactions on Circuits and Systems II: Express Briefs | P1 | 待补 |
| A06 | [Striving for understanding: Deconstructing neural networks in side-channel analysis](A06.md) | Pattern Recognition | P1 | 待补 |
| A09 | [Side-Channel Attacks on Protected Cryptographic Devices in Agentic AI: A Wavelet Scattering-Based Multi-Channel CNN Approach](A09.md) | IEEE Transactions on Cognitive Communications and Networking | P2 | 待补 |
| A10 | [HypSCA: A Hyperbolic Embedding Method for Enhanced Side-Channel Attack](A10.md) | IEEE Transactions on Information Forensics and Security | P3 | 待补 |
