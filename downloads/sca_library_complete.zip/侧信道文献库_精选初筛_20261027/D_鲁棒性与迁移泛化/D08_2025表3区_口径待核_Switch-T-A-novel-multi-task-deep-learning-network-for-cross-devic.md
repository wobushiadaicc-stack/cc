# D08｜Switch-T: A novel multi-task deep-learning network for cross-device side-channel attack

- **来源**：Journal of Information Security and Applications。
- **年份说明**：2025。
- **作者**：Jiale Liao; Huanyu Wang; Junnian Wang; Yun Tang。
- **正式入口**：[10.1016/j.jisa.2025.104146](https://doi.org/10.1016/j.jisa.2025.104146)。
- **收录状态**：按所提供表为三区，不满足一区/二区路线；CCF等价路线另核。
- **阅读优先级 / 难度**：P2 / 中。
- **内容判断依据**：摘要初筛；未逐节精读或复现实验。
- **全文状态**：全文待补。

## 为什么放在这里

Switch-T：多任务Transformer与EWC学习不同设备的功耗和EM特征。

## 阅读时要回答的问题

是否依赖多设备监督训练？任务训练顺序会不会改变结论？

## 前置知识

建模攻击与源域/目标域；先区分跨设备、跨采集、跨算法实现和人工扰动。

## 原文摘要（供检索与初筛）

Side-Channel Analysis has become a realistic threat to cryptographic implementations, particularly with advances in deep-learning techniques. A well-trained neural network can typically make the attack several orders of magnitude more efficient than conventional signal processing approaches. However, like all profiled methods, most existing deep-learning SCAs frameworks require adversaries to develop dedicated models for the specific target device, which complicates the execution of these attacks. In this paper, we propose a Transformer-based neural network, called Switch-T, for multi-task attacks. By collaboratively employing the Elastic Weight Consolidation (EWC) mechanism with a multi-task structure, the model is feasible to learn sensitive data-dependent features of power and EM traces from devices with different core architectures and PCB layout. We experimentally show that the Switch-T model can effectively compromise different implementations of AES. Furthermore, we investigate to which extent the training order of profiling devices can affect the attack efficiency of the model and discuss the impact of hyper-parameter settings in the EWC mechanism.

## 题录证据（核验日：2026-10-27）

- 用户WoS导出记录 W024，UT=WOS:001537392200001
- Crossref正式DOI元数据：https://api.crossref.org/works/10.1016/j.jisa.2025.104146

Crossref日期字段：`{"published": {"date-parts": [[2025, 9]]}, "published-print": {"date-parts": [[2025, 9]]}}`。年份显示以本页“年份说明”区分会议届次、在线年和卷年。

## 2025分区表匹配补充（2026-10-29）

用户提供2025表，第12251行；原表未注明大类/小类，未独立核实官方来源；表中分区：3区。此结果不是官方大类分区核实结论。
