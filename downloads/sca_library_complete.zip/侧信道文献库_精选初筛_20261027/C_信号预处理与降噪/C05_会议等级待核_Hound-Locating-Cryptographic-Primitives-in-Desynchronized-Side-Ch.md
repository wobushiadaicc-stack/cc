# C05｜Hound: Locating Cryptographic Primitives in Desynchronized Side-Channel Traces using Deep-Learning

- **来源**：2024 IEEE 42nd International Conference on Computer Design (ICCD)。
- **年份说明**：ICCD 2024；与预印本W045合并。
- **作者**：Davide Galli; Giuseppe Chiari; Davide Zoni。
- **正式入口**：[10.1109/iccd63220.2024.00027](https://doi.org/10.1109/iccd63220.2024.00027)。
- **收录状态**：方向候选；会议等级待核，不冒用其他会议等级。
- **阅读优先级 / 难度**：P2 / 中。
- **内容判断依据**：摘要初筛；未逐节精读或复现实验。
- **全文状态**：全文待补。

## 为什么放在这里

Hound：定位动态变频扰动下的密码运算，和C04组成连续阅读。

## 阅读时要回答的问题

与随机延迟相比，动态变频让定位和对齐增加了哪些困难？

## 前置知识

采样迹、SNR、GE和基本信号处理；先理解参考迹与攻击者能力。

## 原文摘要（供检索与初筛）

Side-channel attacks allow the extraction of sensitive information from cryptographic primitives by correlating the partially known computed data and the measured side-channel signal. Starting from the raw side-channel trace, the preprocessing of the side-channel trace to pinpoint the time at which each cryptographic primitive is executed, and, then, to re-align all the collected data to this specific time represent a critical step to setup a successful side-channel attack. The use of hiding techniques has been widely adopted as a low-cost solution to hinder the preprocessing of side-channel traces, thus limiting side-channel attacks in real scenarios. This work introduces Hound, a novel deep-learning-based pipeline to locate the execution of cryptographic primitives within the side-channel trace even in the presence of trace deformations introduced by the use of dynamic frequency scaling actuators. Hound has been validated through successful attacks on various cryptographic primitives executed on an FPGA-based systemon-chip incorporating a RISC-V CPU while dynamic frequency scaling is active. Experimental results demonstrate the possibility of identifying the cryptographic primitives in DFS-deformed side-channel traces.

## 题录证据（核验日：2026-10-27）

- 用户WoS导出记录 W046，UT=WOS:001441178200016
- Crossref正式DOI元数据：https://api.crossref.org/works/10.1109/iccd63220.2024.00027

Crossref日期字段：`{"published": {"date-parts": [[2024, 11, 18]]}, "published-print": {"date-parts": [[2024, 11, 18]]}}`。年份显示以本页“年份说明”区分会议届次、在线年和卷年。
