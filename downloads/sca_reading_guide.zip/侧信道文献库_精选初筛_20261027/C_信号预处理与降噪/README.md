# C_信号预处理与降噪

每篇只存入一个主目录。交叉主题通过文献卡中的定位与问题说明。P1是优先阅读，不是发表等级。

## 领域重要来源 / 基础单列

| 编号 | 论文 | 来源 | 优先级 | 全文 |
|---|---|---|---|---|
| C06 | [Optimal Dimensionality Reduction using Conditional Variational AutoEncoder](C06.md) | IACR Transactions on Cryptographic Hardware and Embedded Systems | P2 | 有 |
| C07 | [It’s a Kind of Magic: A Novel Conditional GAN Framework for Efficient Profiling Side-Channel Analysis](C07.md) | Lecture Notes in Computer Science / Advances in Cryptology – ASIACRYPT 2024 | P2 | 待补 |
| C08 | [Diffuse Some Noise: Diffusion Models for Measurement Noise Removal in Side-Channel Analysis](C08.md) | Lecture Notes in Computer Science / Selected Areas in Cryptography – SAC 2025 | P2 | 待补 |

## 等级待核的方向候选

| 编号 | 论文 | 来源 | 优先级 | 全文 |
|---|---|---|---|---|
| C01 | [Side-Channel Attacks Based on Multi-Loss Regularized Denoising AutoEncoder](C01.md) | IEEE Transactions on Information Forensics and Security | P1 | 待补 |
| C02 | [An Effective Tool for Traces Preprocessing in Side-Channel Analysis: Ridge Energies Extraction From Synchrosqueezing Wavelet Transform](C02.md) | IEEE Internet of Things Journal | P1 | 待补 |
| C03 | [A Deep Learning-Assisted Template Attack Against Dynamic Frequency Scaling Countermeasures](C03.md) | IEEE Transactions on Computers | P2 | 待补 |
| C04 | [A Deep- Learning Technique to Locate Cryptographic Operations in Side-Channel Traces](C04.md) | 2024 Design, Automation & Test in Europe Conference & Exhibition (DATE) | P1 | 待补 |
| C05 | [Hound: Locating Cryptographic Primitives in Desynchronized Side-Channel Traces using Deep-Learning](C05.md) | 2024 IEEE 42nd International Conference on Computer Design (ICCD) | P2 | 待补 |
| C09 | [Feature Reconstruction: Far Field EM Side-Channel Attacks in Complex Environment](C09.md) | IEEE Transactions on Information Forensics and Security | P2 | 待补 |
