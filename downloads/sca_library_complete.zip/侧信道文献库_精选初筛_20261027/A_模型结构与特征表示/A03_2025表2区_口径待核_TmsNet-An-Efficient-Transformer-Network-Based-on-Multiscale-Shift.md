# A03｜TmsNet: An Efficient Transformer Network Based on Multiscale Shift-Invariance Mechanism for Side-Channel Analysis

- **来源**：IEEE Internet of Things Journal。
- **年份说明**：2026。
- **作者**：Shengtao Tang; Lang Li; Lianrui Deng; Xingqi Yue。
- **正式入口**：[10.1109/jiot.2026.3685406](https://doi.org/10.1109/jiot.2026.3685406)。
- **收录状态**：按所提供表暂符合一区/二区，待确认口径。
- **阅读优先级 / 难度**：P2 / 中。
- **内容判断依据**：摘要初筛；未逐节精读或复现实验。
- **全文状态**：全文待补。

## 为什么放在这里

TmsNet：多尺度特征、相对位置与Transformer的组合，贴近课题组多尺度路线。

## 阅读时要回答的问题

多尺度模块是否单独有效？参数减少和攻击迹减少能否同时成立？

## 前置知识

CPA、ASCAD标签与GE；CNN基本结构。解释性和双曲表示另需对应数学基础。

## 原文摘要（供检索与初筛）

Transformer architectures have shown strong potential for profiling side-channel analysis (SCA), but their high computational complexity and substantial parameter overhead remain major obstacles to practical deployment in resource-constrained scenarios, especially under severe leakage-trace desynchronization. To address this challenge, we propose TmsNet, an efficient Transformer-based architecture tailored for desynchronized side-channel leakage analysis. TmsNet revisits the Transformer backbone by coupling multiscale leakage representation with shift-aware modeling, thereby reducing model complexity while maintaining strong key-recovery capability under pronounced temporal misalignment. TmsNet is characterized by three key design components. First, it employs a multiscale feature extraction module with temporal convolution kernels of different receptive fields to jointly capture fine-grained local leakage patterns and longer range temporal dependencies, thereby reducing the sensitivity of vanilla Transformers to local misalignment. Second, it introduces a residual fusion mechanism to align and aggregate cross-scale features, yielding more robust feature representations under temporal perturbations. Third, it integrates relative positional encoding with Softmax-based normalization, replacing conventional LayerNorm to better preserve subtle leakage contrasts that may be weakened by mean-variance normalization, while mitigating the impact of countermeasure-induced random delays and clock jitter. Extensive evaluations on the desynchronized ASCADf, ASCADr, and TinyPower benchmark datasets show that TmsNet reduces parameter count by up to 78.5% relative to baseline models while maintaining competitive attack performance. Notably, it recovers the secret key using only 48, 42, and 28 attack traces on the three datasets, respectively, demonstrating an effective balance between architectural efficiency and practical profiling SCA capability.

## 题录证据（核验日：2026-10-27）

- 用户WoS导出记录 W398，UT=WOS:001807857300028
- Crossref正式DOI元数据：https://api.crossref.org/works/10.1109/jiot.2026.3685406

Crossref日期字段：`{"published": {"date-parts": [[2026, 7, 1]]}, "published-print": {"date-parts": [[2026, 7, 1]]}}`。年份显示以本页“年份说明”区分会议届次、在线年和卷年。

## 2025分区表匹配补充（2026-10-29）

用户提供2025表，第8484行；原表未注明大类/小类，未独立核实官方来源；表中分区：2区。此结果不是官方大类分区核实结论。
