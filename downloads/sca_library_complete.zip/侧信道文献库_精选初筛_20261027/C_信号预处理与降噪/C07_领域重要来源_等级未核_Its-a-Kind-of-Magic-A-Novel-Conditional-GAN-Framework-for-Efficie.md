# C07｜It’s a Kind of Magic: A Novel Conditional GAN Framework for Efficient Profiling Side-Channel Analysis

- **来源**：Lecture Notes in Computer Science / Advances in Cryptology – ASIACRYPT 2024。
- **年份说明**：ASIACRYPT 2024；在线2024-12，章节卷年2025；本轮仅核题录。
- **作者**：Sengim Karayalçın; Marina Krček; Lichao Wu; Stjepan Picek; Guilherme Perin。
- **正式入口**：[10.1007/978-981-96-0944-4_4](https://doi.org/10.1007/978-981-96-0944-4_4)。
- **收录状态**：按领域重要来源路线保留；正式发表已核，未声称中科院分区或本轮已核CCF级别。
- **阅读优先级 / 难度**：P2 / 高。
- **内容判断依据**：仅题录/既有说明；需补摘要或全文复筛。
- **全文状态**：全文待补。

## 为什么放在这里

条件GAN建模攻击框架；保留为生成式预处理相关候选，归类需全文复核。

## 阅读时要回答的问题

生成器究竟变换波形、特征还是标签条件？需要怎样的参考实现？

## 前置知识

采样迹、SNR、GE和基本信号处理；先理解参考迹与攻击者能力。

## 内容核验缺口

本轮未取得可核验的完整摘要/正文；中文定位只用于规划阅读，不能作为已证实的方法细节或实验结论。

## 题录证据（核验日：2026-10-27）

- Crossref正式DOI元数据：https://api.crossref.org/works/10.1007/978-981-96-0944-4_4

Crossref日期字段：`{"published": {"date-parts": [[2024, 12, 12]]}, "published-print": {"date-parts": [[2025]]}, "published-online": {"date-parts": [[2024, 12, 12]]}}`。年份显示以本页“年份说明”区分会议届次、在线年和卷年。
