# 01_数据集与评估

每篇只存入一个主目录。交叉主题通过文献卡中的定位与问题说明。P1是优先阅读，不是发表等级。

## 领域重要来源 / 基础单列

| 编号 | 论文 | 来源 | 优先级 | 全文 |
|---|---|---|---|---|
| E01 | [Leading Degree: A Metric for Model Performance Evaluation and Hyperparameter Tuning in Deep Learning-Based Side-Channel Analysis](E01_领域重要来源_等级未核_Leading-Degree-A-Metric-for-Model-Performance-Evaluation-and-Hype.md) | IACR Transactions on Cryptographic Hardware and Embedded Systems | P1 | 有 |
| E02 | [Perceived Information Revisited II: Information-Theoretical Analysis of Deep-Learning Based Side-Channel Attacks](E02_领域重要来源_等级未核_Perceived-Information-Revisited-II-Information-Theoretical-Analys.md) | IACR Transactions on Cryptographic Hardware and Embedded Systems | P2 | 有 |
| E03 | [Multivariate Leakage Detection](E03_领域重要来源_等级未核_Multivariate-Leakage-Detection.md) | IACR Transactions on Cryptographic Hardware and Embedded Systems | P2 | 待补 |
| E04 | [Chameleon: A Dataset for Segmenting and Attacking Obfuscated Power Traces in Side-Channel Analysis](E04_领域重要来源_等级未核_Chameleon-A-Dataset-for-Segmenting-and-Attacking-Obfuscated-Power.md) | IACR Transactions on Cryptographic Hardware and Embedded Systems | P1 | 有 |
| E05 | [The SMAesH dataset: Leakage of a Masked Hardware AES with Information-theoretic Security Bounds](E05_领域重要来源_等级未核_The-SMAesH-dataset-Leakage-of-a-Masked-Hardware-AES-with-Informat.md) | IACR Transactions on Cryptographic Hardware and Embedded Systems | P3 | 有 |
| E06 | [ABBY: Automating leakage modelling for side-channel analysis](E06_领域重要来源_等级未核_ABBY-Automating-leakage-modelling-for-side-channel-analysis.md) | PROCEEDINGS OF THE 19TH ACM ASIA CONFERENCE ON COMPUTER AND COMMUNICATIONS SECURITY, ACM ASIACCS 2024 | P3 | 待补 |
| E07 | [Uncertainty Estimation in Neural Network-enabled Side-channel Analysis and Links to Explainability](E07_领域重要来源_等级未核_Uncertainty-Estimation-in-Neural-Network-enabled-Side-channel-Ana.md) | IACR Transactions on Cryptographic Hardware and Embedded Systems | P2 | 有 |
