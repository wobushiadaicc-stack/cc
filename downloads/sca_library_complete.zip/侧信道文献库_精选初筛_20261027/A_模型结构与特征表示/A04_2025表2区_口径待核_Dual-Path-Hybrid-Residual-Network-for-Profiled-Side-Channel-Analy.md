# A04｜Dual-Path Hybrid Residual Network for Profiled Side-Channel Analysis

- **来源**：IEEE Transactions on Circuits and Systems II: Express Briefs。
- **年份说明**：2024。
- **作者**：Shaofei Sun; Hongwei Yu; An Wang; Congming Wei; Yaoling Ding; Liehuang Zhu; Jiazhe Chen。
- **正式入口**：[10.1109/tcsii.2024.3371110](https://doi.org/10.1109/tcsii.2024.3371110)。
- **收录状态**：按所提供表暂符合一区/二区，待确认口径。
- **阅读优先级 / 难度**：P1 / 中。
- **内容判断依据**：摘要初筛；未逐节精读或复现实验。
- **全文状态**：全文待补。

## 为什么放在这里

双路径混合残差网络：用于理解多尺度与特征融合的具体贡献。

## 阅读时要回答的问题

双路径、残差和多尺度卷积各自贡献多少？对比模型是否充分调参？

## 前置知识

CPA、ASCAD标签与GE；CNN基本结构。解释性和双曲表示另需对应数学基础。

## 原文摘要（供检索与初筛）

Side-channel analysis poses a significant security threat to cryptographic chips in embedded devices. The use of deep learning in side-channel analysis makes it easier to compromise the security of cryptographic chips. Although these chips equipped with countermeasures can increase the complexity of side-channel analysis, it is essential to continue exploring and developing more advanced analysis methods for better security. In this brief, we propose a simple residual network called ResNet-S, which has shown strong performance. Based on this foundation, we have developed the dual-path hybrid residual network. The dual-path hybrid convolution technique is used for feature fusion. It utilizes a multi-scale convolution strategy to effectively reduces the required number of traces for key recovery. We have evaluated the performance of our proposed neural networks on different datasets, and the experimental results show that our proposed networks outperform the state-of-the-art neural networks that have been published.

## 题录证据（核验日：2026-10-27）

- 用户WoS导出记录 W044，UT=WOS:001283904700009
- Crossref正式DOI元数据：https://api.crossref.org/works/10.1109/tcsii.2024.3371110

Crossref日期字段：`{"published": {"date-parts": [[2024, 8]]}, "published-print": {"date-parts": [[2024, 8]]}}`。年份显示以本页“年份说明”区分会议届次、在线年和卷年。

## 2025分区表匹配补充（2026-10-29）

用户提供2025表，第8558行；原表未注明大类/小类，未独立核实官方来源；表中分区：2区。此结果不是官方大类分区核实结论。
