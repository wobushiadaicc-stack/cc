# B_训练策略与学习目标

每篇只存入一个主目录。交叉主题通过文献卡中的定位与问题说明。P1是优先阅读，不是发表等级。

## 领域重要来源 / 基础单列

| 编号 | 论文 | 来源 | 优先级 | 全文 |
|---|---|---|---|---|
| B02 | [HyperSCA: A Comprehensive Hyperparameter Optimization Framework for Deep Learning-based Side Channel Attacks](B02.md) | IACR Transactions on Cryptographic Hardware and Embedded Systems | P1 | 有 |
| B03 | [Scoop: An Optimization Algorithm for Profiling Attacks against Higher-Order Masking](B03.md) | IACR Transactions on Cryptographic Hardware and Embedded Systems | P2 | 有 |
| B09 | [Train Wisely: Multifidelity Bayesian Optimization Hyperparameter Tuning in Deep Learning-Based Side-Channel Analysis](B09.md) | Lecture Notes in Computer Science / Selected Areas in Cryptography – SAC 2024 | P2 | 待补 |

## 等级待核的方向候选

| 编号 | 论文 | 来源 | 优先级 | 全文 |
|---|---|---|---|---|
| B01 | [Being Patient and Persistent: Optimizing An Early Stopping Strategy for Deep Learning in Profiled Attacks](B01.md) | IEEE Transactions on Computers | P1 | 待补 |
| B04 | [CL-SCA: A Contrastive Learning Approach for Profiled Side-Channel Analysis](B04.md) | IEEE Transactions on Information Forensics and Security | P2 | 待补 |
| B05 | [KD-SCA: Improving Lightweight CNN Model Profiling Side-Channel Analysis With Knowledge Distillation](B05.md) | IEEE Transactions on Computer-Aided Design of Integrated Circuits and Systems | P2 | 待补 |
| B06 | [LD-PA: Distilling Univariate Leakage for Deep Learning-Based Profiling Attacks](B06.md) | IEEE Transactions on Information Forensics and Security | P2 | 待补 |
| B07 | [Side-Channel Analysis Based on Multiple Leakage Models Ensemble](B07.md) | IEEE Transactions on Dependable and Secure Computing | P2 | 待补 |
| B08 | [AutoProfile: Automated profiling in deep learning-based side-channel analysis](B08.md) | Neural Networks | P2 | 待补 |
| B10 | [Less is More: Latent Diffusion for Efficient IoT Side-Channel Analysis](B10.md) | IEEE Internet of Things Journal | P3 | 待补 |
