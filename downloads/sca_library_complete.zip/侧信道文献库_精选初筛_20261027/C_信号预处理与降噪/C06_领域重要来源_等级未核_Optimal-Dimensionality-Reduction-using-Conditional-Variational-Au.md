# C06｜Optimal Dimensionality Reduction using Conditional Variational AutoEncoder

- **来源**：IACR Transactions on Cryptographic Hardware and Embedded Systems。
- **年份说明**：TCHES 2025(3)；补回WoS缺失题名。
- **作者**：Sana Boussam; Mathieu Carbone; Benoît Gérard; Guénaël Renault; Gabriel Zaid。
- **正式入口**：[10.46586/tches.v2025.i3.164-211](https://doi.org/10.46586/tches.v2025.i3.164-211)。
- **收录状态**：按领域重要来源路线保留；正式发表已核，未声称中科院分区或本轮已核CCF级别。
- **阅读优先级 / 难度**：P2 / 高。
- **内容判断依据**：摘要初筛；未逐节精读或复现实验。
- **全文状态**：附英文全文（已验证可解析）。

## 为什么放在这里

条件VAE降维：用生成模型和理论结果解释泄漏信息保留。

## 阅读时要回答的问题

无信息损失降维的理论条件是什么？模型假设是否适合掩码与错位迹？

## 前置知识

采样迹、SNR、GE和基本信号处理；先理解参考迹与攻击者能力。

## 本地全文

[C06_领域重要来源_等级未核_Optimal-Dimensionality-Reduction-using-Conditional-Variational-Au.pdf](C06_领域重要来源_等级未核_Optimal-Dimensionality-Reduction-using-Conditional-Variational-Au.pdf)（48 页）。

## 作者代码 / 数据入口

https://github.com/Sbsm157/cVAE-OSM

入口来自论文、官方摘要或既有作者项目；不代表已运行代码或下载数据。

## 原文摘要（供检索与初筛）

The benefits of using Deep Learning techniques to enhance side-channel attacks performances have been demonstrated over recent years. Most of the work carried out since then focuses on discriminative models. However, one of their major limitations is the lack of theoretical results. Indeed, this lack of theoretical results, especially concerning the choice of neural network architecture to consider or the loss to prioritize to build an optimal model, can be problematic for both attackers and evaluators. Recently, Zaid et al. addressed this problem by proposing a generative model that bridges conventional profiled attacks and deep learning techniques, thus providing a model that is both explicable and interpretable. Nevertheless the proposed model has several limitations. Indeed, the architecture is too complex, higher-order attacks cannot be mounted and desynchronization is not handled by this model. In this paper, we address the first limitation namely the architecture complexity, as without a simpler model, the other limitations cannot be treated properly. To do so, we propose a new generative model that relies on solid theoretical results. This model is based on conditional variational autoencoder and converges towards the optimal statistical model i.e. it performs an optimal attack. By building on and extending the state-of-the-art theoretical works on dimensionality reduction, we integrate into this neural network an optimal dimensionality reduction i.e. a dimensionality reduction that is achieved without any loss of information. This results in a gain of O(D), with D the dimension of traces, compared to Zaid et al. neural network in terms of architecture complexity, while at the same time enhancing the explainability and interpretability. In addition, we propose a new attack strategy based on our neural network, which reduces the attack complexity of generative models from O(N) to O(1), with N the number of generated traces. We validate all our theoretical results experimentally using extensive simulations and various publicly available datasets covering symmetric, asymmetric pre and post-quantum cryptography implementations.

## 题录证据（核验日：2026-10-27）

- 用户WoS导出记录 W385，UT=RC:157609336_S24
- Crossref正式DOI元数据：https://api.crossref.org/works/10.46586/tches.v2025.i3.164-211
- 出版方页面：https://tches.iacr.org/index.php/TCHES/article/view/12214

Crossref日期字段：`{"published": {"date-parts": [[2025, 6, 5]]}, "published-online": {"date-parts": [[2025, 6, 5]]}}`。年份显示以本页“年份说明”区分会议届次、在线年和卷年。
