# C03｜A Deep Learning-Assisted Template Attack Against Dynamic Frequency Scaling Countermeasures

- **来源**：IEEE Transactions on Computers。
- **年份说明**：2025。
- **作者**：Davide Galli; Francesco Lattari; Matteo Matteucci; Davide Zoni。
- **正式入口**：[10.1109/tc.2024.3477997](https://doi.org/10.1109/tc.2024.3477997)。
- **收录状态**：按所提供表暂符合一区/二区，待确认口径。
- **阅读优先级 / 难度**：P2 / 中。
- **内容判断依据**：摘要初筛；未逐节精读或复现实验。
- **全文状态**：全文待补。

## 为什么放在这里

DLaTA：深度学习重同步之后执行模板攻击，针对动态变频的真实错位。

## 阅读时要回答的问题

怎样定义重同步参考？预处理与后续模板攻击分别贡献什么？

## 前置知识

采样迹、SNR、GE和基本信号处理；先理解参考迹与攻击者能力。

## 作者代码 / 数据入口

https://github.com/hardware-fab/DLaTA

入口来自论文、官方摘要或既有作者项目；不代表已运行代码或下载数据。

## 原文摘要（供检索与初筛）

In the last decades, machine learning techniques have been extensively used in place of classical template attacks to implement profiled side-channel analysis. This manuscript focuses on the application of machine learning to counteract Dynamic Frequency Scaling defenses. While state-of-the-art attacks have shown promising results against desynchronization countermeasures, a robust attack strategy has yet to be realized. Motivated by the simplicity and effectiveness of template attacks for devices lacking desynchronization countermeasures, this work presents a Deep Learning-assisted Template Attack (DLaTA) methodology specifically designed to target highly desynchronized traces through Dynamic Frequency Scaling. A deep learning-based pre-processing step recovers information obscured by desynchronization, followed by a template attack for key extraction. Specifically, we developed a three-stage deep learning pipeline to resynchronize traces to a uniform reference clock frequency. The experimental results on the AES cryptosystem executed on a RISC-V System-on-Chip reported a Guessing Entropy equal to 1 and a Guessing Distance greater than 0.25. Results demonstrate the method's ability to successfully retrieve secret keys even in the presence of high desynchronization. As an additional contribution, we publicly release our DFS_DESYNCH database(1)(1) https://github.com/hardware-fab/DLaTA containing the first set of real-world highly desynchronized power traces from the execution of a software AES cryptosystem.

## 题录证据（核验日：2026-10-27）

- 用户WoS导出记录 W231，UT=WOS:001377244200023
- Crossref正式DOI元数据：https://api.crossref.org/works/10.1109/tc.2024.3477997

Crossref日期字段：`{"published": {"date-parts": [[2025, 1]]}, "published-print": {"date-parts": [[2025, 1]]}}`。年份显示以本页“年份说明”区分会议届次、在线年和卷年。

## 2025分区表匹配补充（2026-10-29）

用户提供2025表，第8567行；原表未注明大类/小类，未独立核实官方来源；表中分区：2区。此结果不是官方大类分区核实结论。
