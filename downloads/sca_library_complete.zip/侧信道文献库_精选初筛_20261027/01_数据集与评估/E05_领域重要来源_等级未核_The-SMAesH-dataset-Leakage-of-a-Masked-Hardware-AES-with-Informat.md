# E05｜The SMAesH dataset: Leakage of a Masked Hardware AES with Information-theoretic Security Bounds

- **来源**：IACR Transactions on Cryptographic Hardware and Embedded Systems。
- **年份说明**：TCHES 2026；数据规模巨大，目前以阅读为主，无需下载全量数据。
- **作者**：Gaëtan Cassiers; Charles Momin。
- **正式入口**：[10.46586/tches.v2026.i4.917-944](https://doi.org/10.46586/tches.v2026.i4.917-944)。
- **收录状态**：按领域重要来源路线保留；正式发表已核，未声称中科院分区或本轮已核CCF级别。
- **阅读优先级 / 难度**：P3 / 高。
- **内容判断依据**：摘要初筛；未逐节精读或复现实验。
- **全文状态**：附英文全文（已验证可解析）。

## 为什么放在这里

掩码硬件AES数据集与信息论安全界，作为后续硬件评估拓展。

## 阅读时要回答的问题

固定/变化密钥和两块FPGA如何划分？安全界怎样与攻击结果比较？

## 前置知识

CPA/ASCAD与统计指标；信息论条目需熵、互信息和统计估计基础。

## 本地全文

[E05_领域重要来源_等级未核_The-SMAesH-dataset-Leakage-of-a-Masked-Hardware-AES-with-Informat.pdf](E05_领域重要来源_等级未核_The-SMAesH-dataset-Leakage-of-a-Masked-Hardware-AES-with-Informat.pdf)（28 页）。

## 原文摘要（供检索与初筛）

The security of devices against physical side-channel attacks is often evaluated by the performance of attacks. Such an evaluation approach is however costly and evaluated security levels risk being invalidated by progress in attacks over the lifetime of devices. In this paper, we rely on recent information-theoretic results characterizing the security of uniform encodings to assemble a methodology that estimates the number of traces needed to attack a masked implementation.
The validation of this methodology, as well as the development of novel attacks, depends on datasets of side-channel traces. We introduce the SMAesH dataset: power leakage of a masked hardware AES implementation (2 FPGA targets, variable- and fixed-key datasets, in total 288 x 10
6
traces of 4 x 10
3
samples). We apply our evaluation methodology this dataset, and compare it to the best known attacks, demonstrating the relative tightness of the bounds.

## 题录证据（核验日：2026-10-27）

- 出版方页面：https://tches.iacr.org/index.php/TCHES/article/view/13265
