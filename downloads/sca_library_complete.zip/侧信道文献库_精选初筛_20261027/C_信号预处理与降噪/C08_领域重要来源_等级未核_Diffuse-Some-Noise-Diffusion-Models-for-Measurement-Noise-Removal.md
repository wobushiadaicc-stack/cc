# C08｜Diffuse Some Noise: Diffusion Models for Measurement Noise Removal in Side-Channel Analysis

- **来源**：Lecture Notes in Computer Science / Selected Areas in Cryptography – SAC 2025。
- **年份说明**：SAC 2025会议；2026年章节；本轮题录和作者代码说明。
- **作者**：Sengim Karayalçin; Guilherme Perin; Stjepan Picek。
- **正式入口**：[10.1007/978-3-032-10536-3_27](https://doi.org/10.1007/978-3-032-10536-3_27)。
- **收录状态**：按领域重要来源路线保留；正式发表已核，未声称中科院分区或本轮已核CCF级别。
- **阅读优先级 / 难度**：P2 / 中高。
- **内容判断依据**：正式题录＋作者代码README；未读论文正文。
- **全文状态**：全文待补。

## 为什么放在这里

扩散模型去除测量噪声；可与课题组小波GAN和C01进行方法对照。

## 阅读时要回答的问题

训练时是否需要干净参考？扩散步骤数与下游攻击增益怎样权衡？

## 前置知识

采样迹、SNR、GE和基本信号处理；先理解参考迹与攻击者能力。

## 作者代码 / 数据入口

https://github.com/Sengim/diff_release

入口来自论文、官方摘要或既有作者项目；不代表已运行代码或下载数据。

## 内容核验缺口

本轮未取得可核验的完整摘要/正文；中文定位只用于规划阅读，不能作为已证实的方法细节或实验结论。

## 题录证据（核验日：2026-10-27）

- Crossref正式DOI元数据：https://api.crossref.org/works/10.1007/978-3-032-10536-3_27

Crossref日期字段：`{"published": {"date-parts": [[2026]]}, "published-print": {"date-parts": [[2026]]}, "published-online": {"date-parts": [[2026, 1, 2]]}}`。年份显示以本页“年份说明”区分会议届次、在线年和卷年。
