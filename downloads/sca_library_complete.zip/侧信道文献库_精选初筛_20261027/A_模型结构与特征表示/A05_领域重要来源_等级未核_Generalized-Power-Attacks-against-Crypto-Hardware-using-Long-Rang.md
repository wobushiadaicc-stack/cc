# A05｜Generalized Power Attacks against Crypto Hardware using Long-Range Deep Learning

- **来源**：IACR Transactions on Cryptographic Hardware and Embedded Systems。
- **年份说明**：TCHES 2024(3)；补回WoS缺失题名。
- **作者**：Elie Bursztein; Luca Invernizzi; Karel Král; Daniel Moghimi; Jean-Michel Picod; Marina Zhang。
- **正式入口**：[10.46586/tches.v2024.i3.472-499](https://doi.org/10.46586/tches.v2024.i3.472-499)。
- **收录状态**：按领域重要来源路线保留；正式发表已核，未声称中科院分区或本轮已核CCF级别。
- **阅读优先级 / 难度**：P2 / 中高。
- **内容判断依据**：摘要初筛；未逐节精读或复现实验。
- **全文状态**：附英文全文（已验证可解析）。

## 为什么放在这里

长范围深度学习攻击硬件密码实现，拓展从短裁剪迹到长迹的视角。

## 阅读时要回答的问题

长程建模需要多少标签与训练数据？自动化减少了哪些人工步骤？

## 前置知识

CPA、ASCAD标签与GE；CNN基本结构。解释性和双曲表示另需对应数学基础。

## 本地全文

[A05_领域重要来源_等级未核_Generalized-Power-Attacks-against-Crypto-Hardware-using-Long-Rang.pdf](A05_领域重要来源_等级未核_Generalized-Power-Attacks-against-Crypto-Hardware-using-Long-Rang.pdf)（28 页）。

## 原文摘要（供检索与初筛）

To make cryptographic processors more resilient against side-channel attacks, engineers have developed various countermeasures. However, the effectiveness of these countermeasures is often uncertain, as it depends on the complex interplay between software and hardware. Assessing a countermeasure’s effectiveness using profiling techniques or machine learning so far requires significant expertise and effort to be adapted to new targets which makes those assessments expensive. We argue that including cost-effective automated attacks will help chip design teams to quickly evaluate their countermeasures during the development phase, paving the way to more secure chips.In this paper, we lay the foundations toward such automated system by proposing GPAM, the first deep-learning system for power side-channel analysis that generalizes across multiple cryptographic algorithms, implementations, and side-channel countermeasures without the need for manual tuning or trace preprocessing. We demonstrate GPAM’s capability by successfully attacking four hardened hardware-accelerated elliptic-curve digital-signature implementations. We showcase GPAM’s ability to generalize across multiple algorithms by attacking a protected AES implementation and achieving comparable performance to state-of-the-art attacks, but without manual trace curation and within a limited budget. We release our data and models as an open-source contribution to allow the community to independently replicate our results and build on them.

## 题录证据（核验日：2026-10-27）

- 用户WoS导出记录 W283，UT=RC:154387994_S24
- Crossref正式DOI元数据：https://api.crossref.org/works/10.46586/tches.v2024.i3.472-499
- 出版方页面：https://tches.iacr.org/index.php/TCHES/article/view/11685

Crossref日期字段：`{"published": {"date-parts": [[2024, 7, 18]]}, "published-online": {"date-parts": [[2024, 7, 18]]}}`。年份显示以本页“年份说明”区分会议届次、在线年和卷年。
