# D02｜Ablation Analysis for Multi-Device Deep Learning-Based Physical Side-Channel Analysis

- **来源**：IEEE Transactions on Dependable and Secure Computing。
- **年份说明**：TDSC 2024卷年；DOI含2023。
- **作者**：Lichao Wu; Yoo-Seung Won; Dirmanto Jap; Guilherme Perin; Shivam Bhasin; Stjepan Picek。
- **正式入口**：[10.1109/tdsc.2023.3278857](https://doi.org/10.1109/tdsc.2023.3278857)。
- **收录状态**：按所提供表暂符合一区/二区，待确认口径。
- **阅读优先级 / 难度**：P1 / 中。
- **内容判断依据**：摘要初筛；未逐节精读或复现实验。
- **全文状态**：全文待补。

## 为什么放在这里

通过网络层消融与恢复训练，研究从单设备模型出发改善跨设备攻击。

## 阅读时要回答的问题

层敏感性如何定义？恢复训练是否需要目标设备数据或标签？

## 前置知识

建模攻击与源域/目标域；先区分跨设备、跨采集、跨算法实现和人工扰动。

## 原文摘要（供检索与初筛）

The use of deep learning-based side-channel analysis is an effective way of performing profiling attacks on power and electromagnetic leakages, even against targets protected with countermeasures. While many research articles have reported successful results, they typically focus on profiling and attacking a single device, assuming that leakages are similar between devices of the same type. However, this assumption is not always realistic due to variations in hardware and measurement setups, creating what is known as the portability problem. Profiling multiple devices has been proposed as a solution, but obtaining access to these devices may pose a challenge for attackers. This article proposes a new approach to overcome the portability problem by introducing a neural network layer assessment methodology based on the ablation paradigm. This methodology evaluates the sensitivity and resilience of each layer, providing valuable knowledge to create a Multiple Device Model from Single Device (MDMSD). Specifically, it involves ablating a specific neural network section and performing recovery training. As a result, the profiling model, trained initially on a single device, can be generalized to leakage traces measured from various devices. By addressing the portability problem through a single device, practical side-channel attacks could be more accessible and effective for attackers.

## 题录证据（核验日：2026-10-27）

- 用户WoS导出记录 W008，UT=WOS:001224447100011
- Crossref正式DOI元数据：https://api.crossref.org/works/10.1109/tdsc.2023.3278857

Crossref日期字段：`{"published": {"date-parts": [[2024, 5]]}, "published-print": {"date-parts": [[2024, 5]]}}`。年份显示以本页“年份说明”区分会议届次、在线年和卷年。

## 2025分区表匹配补充（2026-10-29）

用户提供2025表，第8572行；原表未注明大类/小类，未独立核实官方来源；表中分区：2区。此结果不是官方大类分区核实结论。
