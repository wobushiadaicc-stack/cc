# E01｜Leading Degree: A Metric for Model Performance Evaluation and Hyperparameter Tuning in Deep Learning-Based Side-Channel Analysis

- **来源**：IACR Transactions on Cryptographic Hardware and Embedded Systems。
- **年份说明**：TCHES 2025；补回WoS缺失题名。
- **作者**：Junfan Zhu; Jiqiang Lu。
- **正式入口**：[10.46586/tches.v2025.i2.333-361](https://doi.org/10.46586/tches.v2025.i2.333-361)。
- **收录状态**：按领域重要来源路线保留；正式发表已核，未声称中科院分区或本轮已核CCF级别。
- **阅读优先级 / 难度**：P1 / 中高。
- **内容判断依据**：摘要初筛；未逐节精读或复现实验。
- **全文状态**：附英文全文（已验证可解析）。

## 为什么放在这里

Leading Degree：把模型选取、攻击评估和调参指标联系起来。

## 阅读时要回答的问题

指标在哪些条件下与GE一致？估计方差与计算时间怎样比较？

## 前置知识

CPA/ASCAD与统计指标；信息论条目需熵、互信息和统计估计基础。

## 本地全文

[E01_领域重要来源_等级未核_Leading-Degree-A-Metric-for-Model-Performance-Evaluation-and-Hype.pdf](E01_领域重要来源_等级未核_Leading-Degree-A-Metric-for-Model-Performance-Evaluation-and-Hype.pdf)（29 页）。

## 原文摘要（供检索与初筛）

Side-channel analysis benefits a lot from deep learning techniques, which assist attackers in recovering the secret key with fewer attack traces than before, but it remains a problem to precisely measure deep learning model performance, so as to obtain a high-performance model. Commonly used evaluation metrics for deep learning like accuracy and precision cannot well meet the demand due to their deviation in side-channel analysis, and classical evaluation metrics for side-channel analysis like guessing entropy, success rate and TGE1 are not generic because they effectively evaluate model performance in only one of the two situations: whether models manage to recover the secret key with given attack traces or not, and not efficient because they need to be performed multiple times to counteract randomness. To attain an effective generic side-channel evaluation metric, we investigate the deterministic component of power consumption, find that the elements of score vector under a key follow a linearly transformed chi-square distribution approximately, and some wrong key hypotheses usually with top scores provide great assistance in model performance evaluation, and finally we propose a new metric called Leading Degree (LD) as well as its simplified version LD-simplified for measuring model performance, which offers similar accuracy but much better generality and efficiency compared with the classical side-channel benchmark metric TGE1, and offers similar generality and efficiency but significantly better accuracy compared with recently proposed sidechannel metrics like Label Correlation and Cross Entropy Ratio. LD/LD-simplified can be easily deployed in early stopping to avoid overfitting phenomena, and we build a bridge between LD/LD-simplified and TGE1, by observing an exponential relationship, which significantly shortens the estimating time for TGE1. At last, we apply LD as a reward function to better solve the reward function design problem in reinforcement learning-based model hyperparameter tuning of side-channel analysis, and obtain better CNN model architectures compared with the state-of-the-art models obtained by previous hyperparameter tuning methods.

## 题录证据（核验日：2026-10-27）

- 用户WoS导出记录 W139，UT=RC:142704849_S24
- Crossref正式DOI元数据：https://api.crossref.org/works/10.46586/tches.v2025.i2.333-361
- 出版方页面：https://tches.iacr.org/index.php/TCHES/article/view/12050

Crossref日期字段：`{"published": {"date-parts": [[2025, 3, 4]]}, "published-online": {"date-parts": [[2025, 3, 4]]}}`。年份显示以本页“年份说明”区分会议届次、在线年和卷年。
