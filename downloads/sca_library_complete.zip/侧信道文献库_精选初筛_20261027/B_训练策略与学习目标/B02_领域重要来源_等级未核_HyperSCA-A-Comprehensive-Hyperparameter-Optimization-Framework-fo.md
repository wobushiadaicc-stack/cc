# B02｜HyperSCA: A Comprehensive Hyperparameter Optimization Framework for Deep Learning-based Side Channel Attacks

- **来源**：IACR Transactions on Cryptographic Hardware and Embedded Systems。
- **年份说明**：TCHES 2026(3)；补回WoS缺失题名。
- **作者**：Yuan Li; Danqing Li; Xiaomei Tang; Bin Zhang; Changhai Ou; Pengcheng Ma; Guangfu Sun。
- **正式入口**：[10.46586/tches.v2026.i3.1105-1127](https://doi.org/10.46586/tches.v2026.i3.1105-1127)。
- **收录状态**：按领域重要来源路线保留；正式发表已核，未声称中科院分区或本轮已核CCF级别。
- **阅读优先级 / 难度**：P1 / 中高。
- **内容判断依据**：摘要初筛；未逐节精读或复现实验。
- **全文状态**：附英文全文（已验证可解析）。

## 为什么放在这里

HyperSCA：统一时间预算下比较超参数优化和侧信道专用损失。

## 阅读时要回答的问题

固定墙钟时间后，方法优势是否仍在？专用损失和搜索算法怎样做消融？

## 前置知识

训练/验证/攻击数据划分、交叉熵和GE；优化/对比学习条目建议先补相应基础。

## 本地全文

[B02_领域重要来源_等级未核_HyperSCA-A-Comprehensive-Hyperparameter-Optimization-Framework-fo.pdf](B02_领域重要来源_等级未核_HyperSCA-A-Comprehensive-Hyperparameter-Optimization-Framework-fo.pdf)（23 页）。

## 原文摘要（供检索与初筛）

Deep learning has become the dominant approach for profiled side-channel analysis (SCA), however, its effectiveness is often limited by a challenging hyperparameter optimization (HPO) process. The field is currently hindered by fundamental limitations: fragmented evaluation methodologies prevent fair comparisons among HPO methods, while the widespread use of generic cryptographically-agnostic loss functions leads to suboptimal attack models. This paper introduces HyperSCA, an automated framework designed to address these challenges. We posit that domainspecific loss functions—designed to align learning objectives with attackers’ operational goals—provide a more efficient means of improving DLSCA performance than complex HPO search strategies. To validate this hypothesis, we introduce two novel SCA-aware loss functions: Distance Correlation (DC) loss and Binomial Distribution (BD) loss, which embed critical cryptographic properties directly into the training process. To enable fair and rigorous evaluation, HyperSCA establishes a unified benchmarking paradigm that enforces a strict wall-clock time budget and optimizes directly for SCA-specific metrics. Extensive evaluations across five public AES datasets support our hypothesis. CNN, MLP, and Transformer models trained with our SCA-aware losses achieve a substantial reduction in trace count for key recovery compared to state-of-the-art methods. This performance gain is achieved within a significantly reduced time budget: from hours or days to under 30 minutes. HyperSCA thus makes HPO more practical for security practitioners. By demonstrating the impact of loss function design, this work provides a new perspective on DLSCA.

## 题录证据（核验日：2026-10-27）

- 用户WoS导出记录 W535，UT=RC:172315636_S24
- Crossref正式DOI元数据：https://api.crossref.org/works/10.46586/tches.v2026.i3.1105-1127
- 出版方页面：https://tches.iacr.org/index.php/TCHES/article/view/13140

Crossref日期字段：`{"published": {"date-parts": [[2026, 7, 17]]}, "published-online": {"date-parts": [[2026, 7, 17]]}}`。年份显示以本页“年份说明”区分会议届次、在线年和卷年。
