# B03｜Scoop: An Optimization Algorithm for Profiling Attacks against Higher-Order Masking

- **来源**：IACR Transactions on Cryptographic Hardware and Embedded Systems。
- **年份说明**：TCHES 2025(3)。
- **作者**：Nathan Rousselot; Karine Heydemann; Loïc Masure; Vincent Migairou。
- **正式入口**：[10.46586/tches.v2025.i3.56-80](https://doi.org/10.46586/tches.v2025.i3.56-80)。
- **收录状态**：按领域重要来源路线保留；正式发表已核，未声称中科院分区或本轮已核CCF级别。
- **阅读优先级 / 难度**：P2 / 高。
- **内容判断依据**：摘要初筛；未逐节精读或复现实验。
- **全文状态**：附英文全文（已验证可解析）。

## 为什么放在这里

研究高阶掩码导致的学习平台期，以二阶优化和稀疏镜像下降改善训练。

## 阅读时要回答的问题

平台期与掩码阶数如何关联？理论推导的假设在真实迹中是否成立？

## 前置知识

训练/验证/攻击数据划分、交叉熵和GE；优化/对比学习条目建议先补相应基础。

## 本地全文

[B03_领域重要来源_等级未核_Scoop-An-Optimization-Algorithm-for-Profiling-Attacks-against-Hig.pdf](B03_领域重要来源_等级未核_Scoop-An-Optimization-Algorithm-for-Profiling-Attacks-against-Hig.pdf)（25 页）。

## 原文摘要（供检索与初筛）

In this paper we provide new theoretical and empirical evidences that gradient-based deep learning profiling attacks (DL-SCA) suffer from masking schemes. This occurs through an initial stall of the learning process: the so-called
plateau effect
. To understand why, we derive an analytical expression of a DL-SCA model targeting simulated traces which enables us to study an analytical expression of the loss. By studying the loss landscape of this model, we show that not only do the magnitudes of the gradients decrease as the order of masking increases, but the loss landscape also exhibits a prominent saddle point interfering with the optimization process. From these observations, we (1) propose the usage of a second-order optimization algorithm mitigating the impact of low-gradient areas. In addition, we show how to leverage the intrinsic sparsity of valuable information in SCA traces to better pose the DL-SCA problem. To do so, we (2) propose to use the implicit regularization properties of the
sparse mirror descent
. These propositions are gathered in a new publicly available optimization algorithm, Scoop. Scoop combines second-order derivative of the loss function in the optimization process, with a sparse stochastic mirror descent. We experimentally show that Scoop pushes further the current limitations of DL-SCA against simulated traces, and outperforms the state-of-theart on the ASCADv1 dataset in terms of number of traces required to retrieve the key, perceived information and plateau length. Scoop also performs the first nonworst- case attack on the ASCADv2 dataset. On simulated traces, we show that using Scoop reduces the DL-SCA time complexity by the equivalent of one masking order.

## 题录证据（核验日：2026-10-27）

- 出版方页面：https://tches.iacr.org/index.php/TCHES/article/view/12210
