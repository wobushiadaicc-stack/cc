# D_鲁棒性与迁移泛化

每篇只存入一个主目录。交叉主题通过文献卡中的定位与问题说明。P1是优先阅读，不是发表等级。

## 领域重要来源 / 基础单列

| 编号 | 论文 | 来源 | 优先级 | 全文 |
|---|---|---|---|---|
| D01 | [A Second Look at the Portability of Deep Learning Side-Channel Attacks over EM Traces](D01.md) | The 27th International Symposium on Research in Attacks, Intrusions and Defenses | P1 | 待补 |
| D04 | [Attack from Shadows: Unsupervised Side-channel Transfer Learning across Devices and Modalities](D04.md) | Proceedings of the ACM Asia Conference on Computer and Communications Security | P2 | 待补 |
| D05 | [Cross-Attention for AES Mode Variation in Side-Channel Analysis](D05.md) | 2025 62nd ACM/IEEE Design Automation Conference (DAC) | P2 | 待补 |
| D10 | [Enhancing Scale and Shift Invariance in Deep Learning-Based Side-Channel Attacks Through Equivariant Convolutional Neural Networks](D10.md) | Lecture Notes in Computer Science / Topics in Cryptology – CT-RSAC 2026 | P2 | 待补 |

## 等级待核的方向候选

| 编号 | 论文 | 来源 | 优先级 | 全文 |
|---|---|---|---|---|
| D02 | [Ablation Analysis for Multi-Device Deep Learning-Based Physical Side-Channel Analysis](D02.md) | IEEE Transactions on Dependable and Secure Computing | P1 | 待补 |
| D03 | [Enhancing Model Generalization for Efficient Cross-Device Side-Channel Analysis](D03.md) | IEEE Transactions on Information Forensics and Security | P2 | 待补 |
| D06 | [Portability of Profiling Side-Channel Analysis: A Case Study Using Adjustable Implementations of Block Ciphers](D06.md) | IEEE Transactions on Information Forensics and Security | P3 | 待补 |
| D07 | [Unleashing Cross-Domain Potential: Side-Channel Analysis with Autoencoder for Domain Adaptation](D07.md) | ACM Transactions on Embedded Computing Systems | P2 | 待补 |
| D08 | [Switch-T: A novel multi-task deep-learning network for cross-device side-channel attack](D08.md) | Journal of Information Security and Applications | P2 | 待补 |
| D09 | [Efficient non-profiled side-channel attack using multi-output deep neural network and transfer learning](D09.md) | Computer Networks | P3 | 待补 |
