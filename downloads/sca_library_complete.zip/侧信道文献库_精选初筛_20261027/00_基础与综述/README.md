# 00_基础与综述

每篇只存入一个主目录。交叉主题通过文献卡中的定位与问题说明。P1是优先阅读，不是发表等级。

## 领域重要来源 / 基础单列

| 编号 | 论文 | 来源 | 优先级 | 全文 |
|---|---|---|---|---|
| F01 | [A Review and Comparison of AI-enhanced Side Channel Analysis](F01_基础综述例外_A-Review-and-Comparison-of-AI-enhanced-Side-Channel-Analysis.md) | ACM Journal on Emerging Technologies in Computing Systems | P1 | 待补 |
| F02 | [Correlation Power Analysis with a Leakage Model](F02_经典例外_Correlation-Power-Analysis-with-a-Leakage-Model.md) | Lecture Notes in Computer Science / Cryptographic Hardware and Embedded Systems - CHES 2004 | P1 | 待补 |
| F03 | [Template Attacks](F03_经典例外_Template-Attacks.md) | Lecture Notes in Computer Science / Cryptographic Hardware and Embedded Systems - CHES 2002 | P1 | 待补 |
| F04 | [Deep learning for side-channel analysis and introduction to ASCAD database](F04_经典例外_Deep-learning-for-side-channel-analysis-and-introduction-to-ASCAD.md) | Journal of Cryptographic Engineering | P1 | 待补 |
| F05 | [Convolutional Neural Networks with Data Augmentation Against Jitter-Based Countermeasures](F05_经典例外_Convolutional-Neural-Networks-with-Data-Augmentation-Against-Jitt.md) | Lecture Notes in Computer Science / Cryptographic Hardware and Embedded Systems – CHES 2017 | P1 | 待补 |
| F06 | [Methodology for Efficient CNN Architectures in Profiling Attacks](F06_经典例外_Methodology-for-Efficient-CNN-Architectures-in-Profiling-Attacks.md) | IACR Transactions on Cryptographic Hardware and Embedded Systems | P1 | 有 |
| F07 | [Remove Some Noise: On Pre-processing of Side-channel Measurements with Autoencoders](F07_经典例外_Remove-Some-Noise-On-Pre-processing-of-Side-channel-Measurements.md) | IACR Transactions on Cryptographic Hardware and Embedded Systems | P1 | 有 |
| F08 | [Pay Attention to Raw Traces: A Deep Learning Architecture for End-to-End Profiling Attacks](F08_经典例外_Pay-Attention-to-Raw-Traces-A-Deep-Learning-Architecture-for-End.md) | IACR Transactions on Cryptographic Hardware and Embedded Systems | P2 | 有 |
