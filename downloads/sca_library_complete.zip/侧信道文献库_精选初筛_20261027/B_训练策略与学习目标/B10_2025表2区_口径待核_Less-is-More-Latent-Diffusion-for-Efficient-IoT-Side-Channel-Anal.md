# B10｜Less is More: Latent Diffusion for Efficient IoT Side-Channel Analysis

- **来源**：IEEE Internet of Things Journal。
- **年份说明**：2026。
- **作者**：Zekai Zhang; Donglong Chen; Wangchen Dai; Jinfa Hong; Yu Hin Chan; Çetin Kaya Koç; Patrick S. Y. Hung; Ray C. C. Cheung。
- **正式入口**：[10.1109/jiot.2026.3685690](https://doi.org/10.1109/jiot.2026.3685690)。
- **收录状态**：按所提供表暂符合一区/二区，待确认口径。
- **阅读优先级 / 难度**：P3 / 中高。
- **内容判断依据**：摘要初筛；未逐节精读或复现实验。
- **全文状态**：全文待补。

## 为什么放在这里

在潜空间用扩散生成侧信道训练迹，主贡献是数据增强而非测试迹去噪。

## 阅读时要回答的问题

合成数据是否泄漏训练/攻击集信息？生成成本和小样本基线怎样比较？

## 前置知识

训练/验证/攻击数据划分、交叉熵和GE；优化/对比学习条目建议先补相应基础。

## 原文摘要（供检索与初筛）

The proliferation of cryptographic primitives in resource-constrained Internet of Things (IoT) devices has made them prime targets for side-channel analysis (SCA). However, designing effective defenses against these attacks has become increasingly complex, as traditional deep learning approaches rely heavily on extensive profiling datasets that are difficult to obtain in the context of widely distributed and physically restricted IoT environments. This challenge is further exacerbated by countermeasures such as clock jitter and random delays. To overcome this limitation, this article introduces a novel and data-efficient three-stage framework for generating high-fidelity synthetic side-channel traces. First, we employ a supervised variational autoencoder (S-VAE) to map noisy, high-dimensional raw traces into a compact and denoised latent space, effectively creating an information-rich manifold. Second, a conditional denoising diffusion implicit model (DDIM), powered by an advanced attention-augmented U-Net, is trained exclusively on this computationally tractable latent space to learn the complex conditional data distribution. Finally, we empirically validate our framework on the public ASCAD benchmark and ChipWhisperer CW308T UFO platform. The results are compelling: an attack model trained solely on our synthetic data can successfully recover the secret key even in the highly challenging ASCAD_desync100 scenario. In addition, on the ChipWhisperer platform, it achieves 97.7% accuracy using only 4107 training traces and 2560 test traces. This work provides a practical and efficient pathway for the robust security evaluation of cryptographic implementations in data-scarce IoT environments, significantly lowering the barrier for thorough side-channel vulnerability analysis.

## 题录证据（核验日：2026-10-27）

- 用户WoS导出记录 W209，UT=WOS:001807857300006
- Crossref正式DOI元数据：https://api.crossref.org/works/10.1109/jiot.2026.3685690

Crossref日期字段：`{"published": {"date-parts": [[2026, 7, 1]]}, "published-print": {"date-parts": [[2026, 7, 1]]}}`。年份显示以本页“年份说明”区分会议届次、在线年和卷年。

## 2025分区表匹配补充（2026-10-29）

用户提供2025表，第8484行；原表未注明大类/小类，未独立核实官方来源；表中分区：2区。此结果不是官方大类分区核实结论。
